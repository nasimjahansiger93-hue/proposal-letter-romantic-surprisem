export type OccasionType = 'valentine' | 'marriage' | 'prom' | 'anniversary' | 'date' | 'custom';

export type ThemeType = 'classic-rose' | 'midnight-gold' | 'lavender-dream' | 'peachy-blossom' | 'sage-romance';

export type SealIconType = 'heart' | 'rose' | 'ring' | 'sparkle' | 'initials';


export type CountdownStyle =
  | 'romantic-glass'
  | 'vintage-parchment'
  | 'neon-midnight'
  | 'rose-gold'
  | 'minimal-pill';

export type CountdownSeparator = 'heart' | 'sparkle' | 'colon' | 'none';

export type CountdownFont = 'serif' | 'sans' | 'mono';

export interface ProposalConfig {
  recipientName: string;
  senderName: string;
  occasionType: OccasionType;
  eyebrowText: string;
  headlinePrefix: string;
  headlineHighlight: string;
  messageBody: string;
  yesButtonText: string;
  maybeButtonText: string;
  yesResponseText: string;
  theme: ThemeType;
  sealIcon: SealIconType;
  initials: string;
  runawayNoButton: boolean;
  photoUrl?: string;
  photoCaption?: string;
  soundEffectsEnabled: boolean;
  showCountdown?: boolean;
  specialDate?: string;
  specialDateTitle?: string;
  countdownStyle?: CountdownStyle;
  countdownSeparator?: CountdownSeparator;
  countdownFont?: CountdownFont;
  countdownCelebrationMessage?: string;
}

export interface ThemeColors {
  id: ThemeType;
  name: string;
  pageBg: string;
  stageBg: string;
  stageBorder: string;
  stageShadow: string;
  envelopeBack: string;
  envelopeFront1: string;
  envelopeFront2: string;
  envelopeFlap: string;
  envelopeBorder: string;
  sealColor: string;
  sealBg: string;
  letterBg: string;
  letterBorder: string;
  textHeading: string;
  textHighlight: string;
  textBody: string;
  textMuted: string;
  buttonYesBg: string;
  buttonYesHover: string;
  buttonYesText: string;
  buttonMaybeBg: string;
  buttonMaybeHover: string;
  buttonMaybeText: string;
  accentStar: string;
  penBody: string;
  penTip: string;
}

export const THEMES: Record<ThemeType, ThemeColors> = {
  'classic-rose': {
    id: 'classic-rose',
    name: 'Classic Rose & Cream',
    pageBg: '#0d1721',
    stageBg: 'linear-gradient(130deg, #fbe3df 0%, #fff4e4 55%, #f9e9d8 100%)',
    stageBorder: 'rgba(255, 255, 255, 0.7)',
    stageShadow: '0 24px 70px rgba(0,0,0,0.32), inset 0 0 0 1px rgba(255,255,255,0.5)',
    envelopeBack: '#f5b6b4',
    envelopeFront1: '#fff1e9',
    envelopeFront2: '#fcebe4',
    envelopeFlap: '#f7c1bd',
    envelopeBorder: '#df9291',
    sealColor: '#ffffff',
    sealBg: '#e84f69',
    letterBg: '#fffaf4',
    letterBorder: '#f1c8bd',
    textHeading: '#9c5559',
    textHighlight: '#e36d7e',
    textBody: '#77504e',
    textMuted: '#a87b78',
    buttonYesBg: '#e96f82',
    buttonYesHover: '#d4576a',
    buttonYesText: '#ffffff',
    buttonMaybeBg: '#f7e5df',
    buttonMaybeHover: '#edd1c8',
    buttonMaybeText: '#9c6260',
    accentStar: '#e88e94',
    penBody: 'linear-gradient(90deg, #e6b96d, #fff0c4, #c58c47)',
    penTip: '#754b2d',
  },
  'midnight-gold': {
    id: 'midnight-gold',
    name: 'Midnight Starlight & Gold',
    pageBg: '#080d14',
    stageBg: 'linear-gradient(135deg, #131c2b 0%, #1a273b 55%, #223249 100%)',
    stageBorder: 'rgba(245, 215, 140, 0.25)',
    stageShadow: '0 24px 70px rgba(0,0,0,0.6), inset 0 0 0 1px rgba(245, 215, 140, 0.2)',
    envelopeBack: '#2c3e55',
    envelopeFront1: '#1f2d3e',
    envelopeFront2: '#27384d',
    envelopeFlap: '#354b66',
    envelopeBorder: '#d4af37',
    sealColor: '#1a273b',
    sealBg: '#e5c158',
    letterBg: '#fbf9f3',
    letterBorder: '#d8c49d',
    textHeading: '#e6c875',
    textHighlight: '#ffd700',
    textBody: '#453828',
    textMuted: '#96a7ba',
    buttonYesBg: '#d4af37',
    buttonYesHover: '#c19c28',
    buttonYesText: '#131c2b',
    buttonMaybeBg: '#2a3b50',
    buttonMaybeHover: '#374c65',
    buttonMaybeText: '#d4af37',
    accentStar: '#ffd700',
    penBody: 'linear-gradient(90deg, #d4af37, #fff2ad, #aa820a)',
    penTip: '#3a2705',
  },
  'lavender-dream': {
    id: 'lavender-dream',
    name: 'Lavender Romance',
    pageBg: '#120f1c',
    stageBg: 'linear-gradient(135deg, #f2e9fc 0%, #f9f5ff 55%, #ede2fa 100%)',
    stageBorder: 'rgba(255, 255, 255, 0.8)',
    stageShadow: '0 24px 70px rgba(18, 15, 28, 0.35), inset 0 0 0 1px rgba(255,255,255,0.6)',
    envelopeBack: '#d7c1f2',
    envelopeFront1: '#f8f4ff',
    envelopeFront2: '#f0e6fc',
    envelopeFlap: '#dfcef7',
    envelopeBorder: '#ba9ce4',
    sealColor: '#ffffff',
    sealBg: '#9b6bd4',
    letterBg: '#fdfbff',
    letterBorder: '#d6c4eb',
    textHeading: '#5a3d7d',
    textHighlight: '#8a4baf',
    textBody: '#4e3f5f',
    textMuted: '#8b7c9e',
    buttonYesBg: '#965fd1',
    buttonYesHover: '#824abb',
    buttonYesText: '#ffffff',
    buttonMaybeBg: '#eedffc',
    buttonMaybeHover: '#e0ccf7',
    buttonMaybeText: '#684a8c',
    accentStar: '#9d6fda',
    penBody: 'linear-gradient(90deg, #ba9ce4, #ffffff, #8a64be)',
    penTip: '#4b2a75',
  },
  'peachy-blossom': {
    id: 'peachy-blossom',
    name: 'Peachy Sunset',
    pageBg: '#181210',
    stageBg: 'linear-gradient(135deg, #ffe8dc 0%, #fff2ea 50%, #fedfcb 100%)',
    stageBorder: 'rgba(255, 255, 255, 0.75)',
    stageShadow: '0 24px 70px rgba(0,0,0,0.3), inset 0 0 0 1px rgba(255,255,255,0.5)',
    envelopeBack: '#f9beaa',
    envelopeFront1: '#fff7f2',
    envelopeFront2: '#feeee3',
    envelopeFlap: '#fac4b2',
    envelopeBorder: '#ee9c84',
    sealColor: '#ffffff',
    sealBg: '#f26848',
    letterBg: '#fffdfa',
    letterBorder: '#fad1c3',
    textHeading: '#9e4630',
    textHighlight: '#e75330',
    textBody: '#704236',
    textMuted: '#a37c73',
    buttonYesBg: '#f26848',
    buttonYesHover: '#dd5333',
    buttonYesText: '#ffffff',
    buttonMaybeBg: '#fae3da',
    buttonMaybeHover: '#f5d3c6',
    buttonMaybeText: '#8f4a38',
    accentStar: '#f78a70',
    penBody: 'linear-gradient(90deg, #f7a992, #fff3ee, #da6f51)',
    penTip: '#6a2818',
  },
  'sage-romance': {
    id: 'sage-romance',
    name: 'Botanical Sage & Linen',
    pageBg: '#0f1713',
    stageBg: 'linear-gradient(135deg, #e3ece5 0%, #f3f7f4 55%, #dce8df 100%)',
    stageBorder: 'rgba(255, 255, 255, 0.75)',
    stageShadow: '0 24px 70px rgba(0,0,0,0.3), inset 0 0 0 1px rgba(255,255,255,0.5)',
    envelopeBack: '#b8cec0',
    envelopeFront1: '#f4f8f5',
    envelopeFront2: '#eaf1ec',
    envelopeFlap: '#c3d6cb',
    envelopeBorder: '#93b5a0',
    sealColor: '#ffffff',
    sealBg: '#4f7d63',
    letterBg: '#fcfdfc',
    letterBorder: '#c3d8cc',
    textHeading: '#325441',
    textHighlight: '#3f6d54',
    textBody: '#3d4d43',
    textMuted: '#778e80',
    buttonYesBg: '#4f7d63',
    buttonYesHover: '#3f6851',
    buttonYesText: '#ffffff',
    buttonMaybeBg: '#e2ede5',
    buttonMaybeHover: '#d2e4d6',
    buttonMaybeText: '#375644',
    accentStar: '#6fa084',
    penBody: 'linear-gradient(90deg, #9bbba8, #f0f7f2, #608871)',
    penTip: '#1f3829',
  },
};

export const DEFAULT_PROPOSAL_CONFIG: ProposalConfig = {
  recipientName: 'Sarah',
  senderName: 'Alex',
  occasionType: 'valentine',
  eyebrowText: 'A little something special',
  headlinePrefix: 'Will you be my',
  headlineHighlight: 'forever Valentine?',
  messageBody:
    'Every little moment feels brighter with you. From our late-night laughs to our quiet coffee mornings, my favorite place in the whole world is right by your side. I would love to make a thousand more memories together.',
  yesButtonText: 'Yes, of course! 💗',
  maybeButtonText: 'Let me think 😊',
  yesResponseText: 'Yay! You just made this moment magical and forever unforgettable. 💖',
  theme: 'classic-rose',
  sealIcon: 'heart',
  initials: 'S+A',
  runawayNoButton: false,
  photoUrl: '',
  photoCaption: 'Us making memories 📸',
  soundEffectsEnabled: true,
  showCountdown: true,
  specialDate: '2027-02-14T00:00',
  specialDateTitle: "Until Our Valentine's Day 💖",
  countdownStyle: 'romantic-glass',
  countdownSeparator: 'heart',
  countdownFont: 'serif',
  countdownCelebrationMessage: 'Today is Our Special Day! The magical moment has arrived 💖',
};

export const OCCASION_PRESETS: Record<
  OccasionType,
  {
    name: string;
    icon: string;
    eyebrow: string;
    prefix: string;
    highlight: string;
    body: string;
    yesText: string;
    maybeText: string;
    yesReply: string;
  }
> = {
  valentine: {
    name: "Valentine's Day",
    icon: '💝',
    eyebrow: 'A little something special',
    prefix: 'Will you be my',
    highlight: 'forever Valentine?',
    body: 'Every little moment feels brighter with you. I would love to make a thousand more memories together.',
    yesText: 'Yes, of course! 💗',
    maybeText: 'Let me think 😊',
    yesReply: 'Yay! You just made this moment magical. 💖',
  },
  marriage: {
    name: 'Marriage Proposal',
    icon: '💍',
    eyebrow: 'A question from the heart',
    prefix: 'Sarah,',
    highlight: 'Will you marry me?',
    body: 'Loving you is the easiest and most beautiful choice I make every single day. I want to build a life, a home, and endless dreams with you forever.',
    yesText: 'YES! A thousand times yes! 💍✨',
    maybeText: 'Let me catch my breath 🥹',
    yesReply: 'Forever begins today! I love you with all my heart. 💍❤️🥂',
  },
  prom: {
    name: 'Prom / Dance Proposal',
    icon: '✨',
    eyebrow: 'An enchanted invitation',
    prefix: 'Would you do me the honor and',
    highlight: 'go to Prom with me?',
    body: 'There is nobody else in the room I would rather dance all night with. Let’s make it an unforgettable night!',
    yesText: 'Yes! Let’s dance! 💃✨',
    maybeText: 'Only if we dance slow 😉',
    yesReply: 'It is a date! Get ready for the best night ever! 🌟🎉',
  },
  anniversary: {
    name: 'Anniversary Love Letter',
    icon: '💌',
    eyebrow: 'Celebrating our journey',
    prefix: 'Happy Anniversary my love,',
    highlight: 'Here’s to forever together.',
    body: 'Thank you for being my rock, my greatest adventure, and my true happiness. I love you more and more every single day.',
    yesText: 'To another lifetime! 🥂💕',
    maybeText: 'You still owe me dinner! 😋',
    yesReply: 'Happy anniversary, sweetheart! Forever yours. 🥂🌹',
  },
  date: {
    name: 'Date Invitation',
    icon: '☕',
    eyebrow: 'A sweet invitation',
    prefix: 'Can I take you out on',
    highlight: 'a real dinner date this Friday?',
    body: 'Good food, your favorite music, and hours of talking together. What do you say?',
    yesText: 'Count me in! 🥰🍷',
    maybeText: 'Depends, who is picking the dessert? 🍰',
    yesReply: 'Awesome! It’s a date, I can’t wait! 🕯️✨',
  },
  custom: {
    name: 'Custom Surprise',
    icon: '✏️',
    eyebrow: 'A surprise for you',
    prefix: 'Hey there,',
    highlight: 'I have something to say...',
    body: 'Write your heartfelt message here to surprise your favorite person in the world.',
    yesText: 'Yes! 💗',
    maybeText: 'Tell me more 😊',
    yesReply: 'You made my whole day! 💖',
  },
};
