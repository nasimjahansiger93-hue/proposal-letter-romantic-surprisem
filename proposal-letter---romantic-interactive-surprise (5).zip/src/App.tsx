import { useState, useEffect, useRef } from 'react';
import {
  ProposalConfig,
  THEMES,
} from './types';
import { decodeProposalFromUrl } from './utils/share';
import { playEnvelopeOpenSound } from './utils/audio';
import { Envelope } from './components/Envelope';
import { ProposalCard } from './components/ProposalCard';
import { FloatingHearts, FloatingHeartsHandle } from './components/FloatingHearts';
import { CustomizerModal } from './components/CustomizerModal';
import { KeepsakeModal } from './components/KeepsakeModal';
import { CountdownTimer } from './components/CountdownTimer';
import {
  Volume2,
  VolumeX,
  Settings2,
  RotateCcw,
} from 'lucide-react';

export default function App() {
  const [config, setConfig] = useState<ProposalConfig>(() => decodeProposalFromUrl());
  const [isOpen, setIsOpen] = useState(false);
  const [isCustomizerOpen, setIsCustomizerOpen] = useState(false);
  const [customizerTab, setCustomizerTab] = useState<
    'presets' | 'content' | 'polaroid' | 'countdown' | 'style' | 'share'
  >('presets');
  const [isKeepsakeOpen, setIsKeepsakeOpen] = useState(false);
  const heartsRef = useRef<FloatingHeartsHandle>(null);

  const currentTheme = THEMES[config.theme] || THEMES['classic-rose'];

  // Handle URL change or load
  useEffect(() => {
    const loadedConfig = decodeProposalFromUrl();
    setConfig(loadedConfig);
  }, []);

  const handleOpenEnvelope = () => {
    if (isOpen) return;
    setIsOpen(true);
    playEnvelopeOpenSound(config.soundEffectsEnabled);
    heartsRef.current?.burst(20);
  };

  const handleReset = () => {
    setIsOpen(false);
  };

  const toggleSoundFx = () => {
    setConfig((prev) => ({
      ...prev,
      soundEffectsEnabled: !prev.soundEffectsEnabled,
    }));
  };

  return (
    <div
      className="min-h-screen w-full flex flex-col items-center justify-between px-3 sm:px-6 py-6 sm:py-8 transition-colors duration-700 relative selection:bg-rose-500/30 selection:text-white"
      style={{ backgroundColor: currentTheme.pageBg }}
    >
      {/* Background Decorative Ambient Glows */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div
          className="absolute -top-32 -left-32 w-96 h-96 rounded-full blur-3xl opacity-20 transition-all duration-700"
          style={{ backgroundColor: currentTheme.sealBg }}
        />
        <div
          className="absolute -bottom-32 -right-32 w-96 h-96 rounded-full blur-3xl opacity-15 transition-all duration-700"
          style={{ backgroundColor: currentTheme.textHighlight }}
        />
      </div>

      {/* Top Floating Control Bar */}
      <nav className="w-full max-w-2xl flex items-center justify-between gap-2 z-30 mb-4 sm:mb-6">
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Sound FX Toggle */}
          <button
            type="button"
            onClick={toggleSoundFx}
            title={config.soundEffectsEnabled ? 'Mute sound effects' : 'Enable sound effects'}
            className={`p-2 rounded-full border text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer backdrop-blur-md ${
              config.soundEffectsEnabled
                ? 'bg-stone-900/60 border-stone-800 text-stone-300'
                : 'bg-stone-900/40 border-stone-800 text-stone-500'
            }`}
          >
            {config.soundEffectsEnabled ? (
              <Volume2 className="w-3.5 h-3.5" />
            ) : (
              <VolumeX className="w-3.5 h-3.5" />
            )}
            <span className="hidden sm:inline text-[11px]">
              {config.soundEffectsEnabled ? 'SFX' : 'Muted'}
            </span>
          </button>
        </div>

        {/* Right Action Tools */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {isOpen && (
            <button
              type="button"
              onClick={handleReset}
              title="Close & re-seal envelope"
              className="p-2 sm:px-3 rounded-full border border-stone-800 bg-stone-900/60 hover:bg-stone-800/80 text-stone-300 text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer backdrop-blur-md"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline text-[11px]">Re-seal</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              setCustomizerTab('presets');
              setIsCustomizerOpen(true);
            }}
            className="px-3.5 py-1.5 rounded-full border border-rose-500/40 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer backdrop-blur-md shadow-xs"
          >
            <Settings2 className="w-3.5 h-3.5" />
            <span>Customize</span>
          </button>
        </div>
      </nav>

      {/* Main Content Page Container */}
      <main className="w-full max-w-[680px] flex-1 flex flex-col items-center justify-center z-10">
        {/* Header Section from original website */}
        <header className="text-center mb-6 sm:mb-8 select-none">
          <p className="text-[10px] sm:text-[11px] font-bold uppercase tracking-[0.24em] text-stone-400 mb-2">
            {config.eyebrowText || 'A LITTLE SOMETHING SPECIAL'}
          </p>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-none">
            <span className="text-[#c7f36b] drop-shadow-xs">Proposal Letter</span>{' '}
            <span className="opacity-90">CSS</span>
          </h1>
          <p className="text-stone-400 text-xs sm:text-sm mt-3 font-normal max-w-md mx-auto">
            A tiny interactive surprise, made with love.
          </p>
        </header>

        {/* Live Countdown Timer to Special Date (Below Header) */}
        {config.showCountdown !== false && config.specialDate && (
          <CountdownTimer
            specialDate={config.specialDate}
            specialDateTitle={config.specialDateTitle}
            theme={currentTheme}
            countdownStyle={config.countdownStyle}
            countdownSeparator={config.countdownSeparator}
            countdownFont={config.countdownFont}
            countdownCelebrationMessage={config.countdownCelebrationMessage}
            onOpenCustomizer={() => {
              setCustomizerTab('countdown');
              setIsCustomizerOpen(true);
            }}
          />
        )}

        {/* The Romantic Stage Box (Original CSS Card replica) */}
        <section
          className={`relative w-full rounded-2xl transition-all duration-700 px-5 sm:px-8 py-8 sm:py-10 select-none overflow-hidden ${
            isOpen ? 'min-h-[580px]' : 'min-h-[480px]'
          }`}
          style={{
            background: currentTheme.stageBg,
            boxShadow: currentTheme.stageShadow,
            border: `1px solid ${currentTheme.stageBorder}`,
            color: currentTheme.textHeading,
          }}
          aria-label="Interactive proposal letter"
        >
          {/* Floating Hearts Particle Layer */}
          <FloatingHearts ref={heartsRef} color={currentTheme.sealBg} />

          {/* Decorative Dotted Calligraphy Corners */}
          <div
            className="absolute top-4 left-3 text-xs tracking-[15px] opacity-60 pointer-events-none select-none font-serif"
            style={{ color: currentTheme.accentStar, transform: 'rotate(-8deg)' }}
          >
            · ♥ · ✧ · ♥
          </div>
          <div
            className="absolute bottom-4 right-[-30px] text-xs tracking-[15px] opacity-60 pointer-events-none select-none font-serif"
            style={{ color: currentTheme.accentStar, transform: 'rotate(-12deg)' }}
          >
            · ♥ · ✧ · ♥
          </div>

          {/* Sparkles from original design */}
          <div
            className="absolute top-[22%] left-[12%] text-lg font-serif select-none pointer-events-none animate-twinkle"
            style={{ color: currentTheme.accentStar }}
          >
            ✦
          </div>
          <div
            className="absolute top-[38%] right-[10%] text-sm select-none pointer-events-none animate-twinkle"
            style={{ color: currentTheme.textHighlight, animationDelay: '1s' }}
          >
            ♥
          </div>
          <div
            className="absolute bottom-[16%] left-[20%] text-xl font-serif select-none pointer-events-none animate-twinkle"
            style={{ color: currentTheme.accentStar, animationDelay: '2s' }}
          >
            ✧
          </div>

          {/* 3D Envelope Component */}
          <Envelope
            isOpen={isOpen}
            onOpen={handleOpenEnvelope}
            theme={currentTheme}
            sealIcon={config.sealIcon}
            initials={config.initials}
            recipientName={config.recipientName}
            senderName={config.senderName}
            eyebrowText={config.eyebrowText}
            soundEffectsEnabled={config.soundEffectsEnabled}
          />

          {/* Revealed Proposal Card */}
          {isOpen && (
            <ProposalCard
              config={config}
              theme={currentTheme}
              onOpenKeepsake={() => setIsKeepsakeOpen(true)}
              onReset={handleReset}
              onHeartBurst={(count) => heartsRef.current?.burst(count)}
            />
          )}
        </section>

        {/* Footer */}
        <footer className="mt-8 text-center text-[10px] sm:text-[11px] font-bold tracking-[0.2em] uppercase text-stone-500 select-none">
          MADE WITH <span className="text-rose-400">♥</span> & A LITTLE CSS MAGIC
        </footer>
      </main>

      {/* Keepsake Certificate Modal */}
      <KeepsakeModal
        isOpen={isKeepsakeOpen}
        onClose={() => setIsKeepsakeOpen(false)}
        config={config}
        theme={currentTheme}
      />

      {/* Personalization / Customizer Modal */}
      <CustomizerModal
        isOpen={isCustomizerOpen}
        onClose={() => setIsCustomizerOpen(false)}
        config={config}
        onChangeConfig={setConfig}
        initialTab={customizerTab}
      />
    </div>
  );
}
