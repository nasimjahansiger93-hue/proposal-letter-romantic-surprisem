import React, { useState, useRef, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { ProposalConfig, ThemeColors } from '../types';
import { playYesChime, playPlayfulBoop } from '../utils/audio';
import { Heart, Sparkles, Award, RotateCcw } from 'lucide-react';

interface ProposalCardProps {
  config: ProposalConfig;
  theme: ThemeColors;
  onOpenKeepsake: () => void;
  onReset: () => void;
  onHeartBurst: (count?: number) => void;
}

const PLAYFUL_EXCUSES = [
  'Let me think 😊',
  'Are you really sure? 🥺',
  'What if I bring you chocolates? 🍫',
  'Think of all the laughs we share! ✨',
  'Look how good we look together! 🌸',
  'I will make you pancakes every Sunday! 🥞',
  'Okay, please? Just say yes! 💖',
];

export const ProposalCard: React.FC<ProposalCardProps> = ({
  config,
  theme,
  onOpenKeepsake,
  onReset,
  onHeartBurst,
}) => {
  const [accepted, setAccepted] = useState(false);
  const [maybeCount, setMaybeCount] = useState(0);
  const [maybePosition, setMaybePosition] = useState<{ x: number; y: number } | null>(null);
  const [replyMessage, setReplyMessage] = useState<string>('');
  const [displayedText, setDisplayedText] = useState<string>('');
  const [isTypingComplete, setIsTypingComplete] = useState<boolean>(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Character-by-character typing animation when card is opened/mounted
  useEffect(() => {
    const fullText = config.messageBody || '';
    if (!fullText) {
      setDisplayedText('');
      setIsTypingComplete(true);
      return;
    }

    setDisplayedText('');
    setIsTypingComplete(false);

    let currentIndex = 0;
    // Smooth dynamic typing speed based on letter length
    const charDelay = fullText.length > 300 ? 16 : fullText.length > 150 ? 22 : 28;

    const timer = setInterval(() => {
      currentIndex++;
      if (currentIndex <= fullText.length) {
        setDisplayedText(fullText.slice(0, currentIndex));
      } else {
        setIsTypingComplete(true);
        clearInterval(timer);
      }
    }, charDelay);

    return () => clearInterval(timer);
  }, [config.messageBody]);

  const handleSkipTyping = () => {
    if (!isTypingComplete) {
      setDisplayedText(config.messageBody || '');
      setIsTypingComplete(true);
    }
  };

  const handleYes = () => {
    handleSkipTyping();
    setAccepted(true);
    setReplyMessage(config.yesResponseText);

    // Audio chime
    playYesChime(config.soundEffectsEnabled);

    // Trigger floating hearts
    onHeartBurst(28);

    // Canvas confetti burst
    confetti({
      particleCount: 80,
      spread: 75,
      origin: { y: 0.65 },
      colors: ['#e85e76', '#f5b6b4', '#ffd700', '#ffffff', '#e96f82'],
    });

    setTimeout(() => {
      confetti({
        particleCount: 50,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#e85e76', '#ffd700', '#f4a6b6'],
      });
      confetti({
        particleCount: 50,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#e85e76', '#ffd700', '#f4a6b6'],
      });
    }, 280);
  };

  const handleMaybe = () => {
    handleSkipTyping();
    if (config.runawayNoButton) {
      dodgeButton();
      return;
    }

    const nextCount = maybeCount + 1;
    setMaybeCount(nextCount);
    playPlayfulBoop(config.soundEffectsEnabled);

    if (nextCount === 1) {
      setReplyMessage('No rush at all. Some sweet surprises are worth a little thought. 🌷');
    } else if (nextCount < PLAYFUL_EXCUSES.length) {
      setReplyMessage(`"${PLAYFUL_EXCUSES[nextCount]}" — I'll wait as long as it takes! 🥰`);
    } else {
      setReplyMessage("You know the answer in your heart... it's a YES! 💕");
    }
  };

  const dodgeButton = () => {
    playPlayfulBoop(config.soundEffectsEnabled);
    const nextCount = maybeCount + 1;
    setMaybeCount(nextCount);

    // Random offset inside bounded container
    const randomX = (Math.random() - 0.5) * 160;
    const randomY = (Math.random() - 0.5) * 80;
    setMaybePosition({ x: randomX, y: randomY });
  };

  return (
    <div
      ref={containerRef}
      className="w-full max-w-md mx-auto mt-4 px-6 py-7 rounded-2xl border transition-all duration-700 animate-in fade-in slide-in-from-bottom-4"
      style={{
        backgroundColor: theme.letterBg,
        borderColor: theme.letterBorder,
        boxShadow: `0 16px 40px rgba(0,0,0,0.12), 0 2px 6px ${theme.letterBorder}`,
      }}
    >
      {/* Kicker / To Recipient */}
      <div className="flex items-center justify-between border-b pb-2.5 mb-4" style={{ borderColor: `${theme.letterBorder}88` }}>
        <p
          className="text-[10px] font-bold tracking-[0.24em] uppercase"
          style={{ color: theme.textHighlight }}
        >
          TO MY DEAREST {config.recipientName.toUpperCase() || 'LOVE'}
        </p>
        <span className="text-xs" style={{ color: theme.textHighlight }}>
          ♥
        </span>
      </div>

      {/* Main Proposal Headline */}
      <h2
        className="text-2xl sm:text-3xl font-bold leading-tight tracking-tight mb-3"
        style={{
          fontFamily: 'var(--font-serif)',
          color: theme.textHeading,
        }}
      >
        {config.headlinePrefix}{' '}
        <em
          className="font-normal italic block sm:inline transition-colors duration-300"
          style={{ color: theme.textHighlight }}
        >
          {config.headlineHighlight}
        </em>
      </h2>

      {/* Polaroid Keepsake Photo */}
      {config.photoUrl && (
        <div className="my-5 relative max-w-[210px] sm:max-w-[220px] mx-auto transform -rotate-2 hover:rotate-0 transition-transform duration-300 group">
          {/* Top Washi Tape strip */}
          <div
            className="absolute -top-3 left-1/2 -translate-x-1/2 w-16 h-4 z-10 pointer-events-none opacity-85 shadow-xs"
            style={{
              backgroundColor: 'rgba(235, 142, 160, 0.75)',
              transform: 'rotate(-1.5deg)',
              clipPath: 'polygon(0% 0%, 100% 0%, 97% 100%, 3% 100%)',
            }}
          />

          <div className="bg-[#fcfbf9] p-2.5 pb-3.5 rounded-sm shadow-xl border border-stone-200/90 transition-shadow">
            <img
              src={config.photoUrl}
              alt="Romantic Keepsake"
              className="w-full h-auto rounded-[2px] shadow-xs object-cover"
            />
            {/* If not an embedded canvas Polaroid, show the handwritten caption underneath */}
            {config.photoCaption && !config.photoUrl.startsWith('data:image') && (
              <p
                className="text-center text-sm mt-2 font-bold text-stone-700 tracking-wide"
                style={{ fontFamily: 'var(--font-hand)' }}
              >
                {config.photoCaption}
              </p>
            )}
          </div>
        </div>
      )}

      {/* Proposal Body Text with Typing Animation */}
      <div
        onClick={handleSkipTyping}
        className="text-xs sm:text-sm leading-relaxed mb-6 font-normal whitespace-pre-line relative min-h-[4rem] select-text cursor-default"
        style={{ color: theme.textBody }}
        title={!isTypingComplete ? 'Click to reveal instantly' : undefined}
      >
        <span>{displayedText}</span>
        {!isTypingComplete && (
          <span
            className="inline-block w-1.5 h-3.5 sm:h-4 ml-0.5 align-middle opacity-85 animate-pulse rounded-xs"
            style={{ backgroundColor: theme.textHighlight }}
            aria-hidden="true"
          />
        )}
      </div>

      {/* Sender Sign-off */}
      <div className="text-right mb-6 pr-2">
        <p className="text-[11px] italic" style={{ color: theme.textMuted }}>
          Forever yours,
        </p>
        <p
          className="text-lg font-bold"
          style={{
            fontFamily: 'var(--font-hand)',
            color: theme.textHeading,
          }}
        >
          {config.senderName || 'Your Love'}
        </p>
      </div>

      {/* Choices Buttons */}
      {!accepted ? (
        <div className="relative min-h-[50px] flex items-center justify-center flex-wrap gap-3">
          {/* YES Button */}
          <button
            type="button"
            onClick={handleYes}
            className="px-6 py-2.5 rounded-full font-semibold text-xs sm:text-sm tracking-wide shadow-md transition-all duration-300 transform hover:-translate-y-0.5 active:scale-95 cursor-pointer flex items-center gap-1.5"
            style={{
              backgroundColor: theme.buttonYesBg,
              color: theme.buttonYesText,
              boxShadow: `0 6px 16px ${theme.buttonYesBg}44`,
            }}
          >
            <Heart className="w-3.5 h-3.5 fill-current" />
            <span>{config.yesButtonText}</span>
          </button>

          {/* MAYBE / NO Button */}
          <button
            type="button"
            onClick={handleMaybe}
            onMouseEnter={config.runawayNoButton ? dodgeButton : undefined}
            className="px-5 py-2.5 rounded-full font-medium text-xs sm:text-sm tracking-wide transition-all duration-300 transform active:scale-95 cursor-pointer select-none"
            style={{
              backgroundColor: theme.buttonMaybeBg,
              color: theme.buttonMaybeText,
              transform: maybePosition
                ? `translate(${maybePosition.x}px, ${maybePosition.y}px)`
                : undefined,
              transition: maybePosition ? 'transform 0.22s ease-out' : 'all 0.2s ease',
            }}
          >
            <span>
              {config.runawayNoButton
                ? 'No 😜'
                : PLAYFUL_EXCUSES[maybeCount % PLAYFUL_EXCUSES.length] || config.maybeButtonText}
            </span>
          </button>
        </div>
      ) : (
        /* Accepted Celebration State */
        <div className="space-y-4 animate-in fade-in duration-500">
          <div
            className="p-3.5 rounded-xl text-center border shadow-xs"
            style={{
              backgroundColor: `${theme.stageBorder}44`,
              borderColor: theme.stageBorder,
            }}
          >
            <div className="flex items-center justify-center gap-1.5 mb-1 text-sm font-bold" style={{ color: theme.textHighlight }}>
              <Sparkles className="w-4 h-4" />
              <span>SHE / HE SAID YES!</span>
              <Sparkles className="w-4 h-4" />
            </div>
            <p className="text-xs sm:text-sm font-semibold" style={{ color: theme.textHeading }}>
              {replyMessage}
            </p>
          </div>

          {/* Keepsake Certificate & Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
            <button
              type="button"
              onClick={onOpenKeepsake}
              className="px-4 py-2 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs hover:shadow-md cursor-pointer"
              style={{
                backgroundColor: theme.buttonYesBg,
                color: theme.buttonYesText,
              }}
            >
              <Award className="w-3.5 h-3.5" />
              <span>View Keepsake Card</span>
            </button>

            <button
              type="button"
              onClick={onReset}
              className="px-3.5 py-2 rounded-full text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer border"
              style={{
                borderColor: theme.letterBorder,
                color: theme.textMuted,
                backgroundColor: 'transparent',
              }}
              title="Close and re-seal envelope"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Replay</span>
            </button>
          </div>
        </div>
      )}

      {/* Reply feedback notice if maybe was tapped */}
      {!accepted && replyMessage && (
        <p
          className="text-center text-xs font-semibold mt-3 animate-in fade-in duration-300"
          style={{ color: theme.textHighlight }}
        >
          {replyMessage}
        </p>
      )}
    </div>
  );
};
