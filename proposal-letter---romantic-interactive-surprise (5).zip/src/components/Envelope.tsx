import React from 'react';
import { ThemeColors, SealIconType } from '../types';
import { DigitalWaxSeal } from './DigitalWaxSeal';

interface EnvelopeProps {
  isOpen: boolean;
  onOpen: () => void;
  theme: ThemeColors;
  sealIcon: SealIconType;
  initials: string;
  recipientName: string;
  senderName: string;
  eyebrowText?: string;
  soundEffectsEnabled?: boolean;
}

export const Envelope: React.FC<EnvelopeProps> = ({
  isOpen,
  onOpen,
  theme,
  sealIcon,
  initials,
  recipientName,
  soundEffectsEnabled = true,
}) => {
  return (
    <div className="flex flex-col items-center select-none">
      {/* 3D Envelope Container */}
      <div className="perspective-900 w-full flex justify-center py-2">
        <div
          className={`group relative outline-none transition-transform duration-300 ${
            !isOpen ? 'hover:-translate-y-1 hover:rotate-[-0.3deg]' : ''
          }`}
        >
          {/* Main Envelope Body */}
          <div
            className={`relative w-48 h-34 md:w-52 md:h-36 transition-all duration-700 ${
              isOpen ? 'envelope-open' : ''
            }`}
            style={{
              filter: isOpen
                ? 'drop-shadow(0 14px 22px rgba(0,0,0,0.2))'
                : 'drop-shadow(0 12px 18px rgba(150,75,75,0.22))',
            }}
          >
            {/* 1. Envelope Back Plate */}
            <div
              className="absolute inset-0 rounded-lg border-2 transition-colors duration-500"
              style={{
                backgroundColor: theme.envelopeBack,
                borderColor: theme.envelopeBorder,
              }}
            />

            {/* 2. Letter Peek (Slides Upwards When Open) */}
            <div
              className={`letter-rise absolute left-3 right-3 bottom-2 h-26 rounded-md flex flex-col items-center justify-center p-2 z-10 transition-transform duration-700 ${
                isOpen ? '-translate-y-20 md:-translate-y-24 shadow-xl' : 'translate-y-0'
              }`}
              style={{
                backgroundColor: theme.letterBg,
                border: `1px solid ${theme.letterBorder}`,
              }}
            >
              {/* Little Heart & Handwritten lines simulation */}
              <span
                className="text-lg md:text-xl transition-colors duration-300"
                style={{ color: theme.sealBg }}
              >
                ♥
              </span>
              <div
                className="w-14 h-0.5 mt-2 rounded-full opacity-60"
                style={{
                  backgroundColor: theme.letterBorder,
                  boxShadow: `0 5px 0 ${theme.letterBorder}, 0 10px 0 ${theme.letterBorder}`,
                }}
              />
              <span
                className="mt-4 text-[9px] font-semibold tracking-wider uppercase opacity-75 font-sans"
                style={{ color: theme.textMuted }}
              >
                For {recipientName}
              </span>
            </div>

            {/* 3. Envelope Front Pocket (Lower Triangular Folds) */}
            <div
              className="absolute inset-0 z-20 rounded-b-lg overflow-hidden pointer-events-none"
              style={{
                borderBottom: `2px solid ${theme.envelopeBorder}`,
              }}
            >
              <div
                className="absolute inset-0"
                style={{
                  background: `
                    linear-gradient(145deg, transparent 49.3%, ${theme.envelopeFront1} 50%) bottom right/50% 100% no-repeat,
                    linear-gradient(215deg, transparent 49.3%, ${theme.envelopeFront2} 50%) bottom left/50% 100% no-repeat
                  `,
                }}
              />
            </div>

            {/* 4. Envelope Top Flap (3D Folding Flap) */}
            <div
              className={`envelope-flap-fold absolute top-0 left-0 w-full h-[62%] z-30 transition-all duration-700 ${
                isOpen ? 'envelope-open' : ''
              }`}
              style={{
                backgroundColor: theme.envelopeFlap,
                clipPath: 'polygon(0 0, 100% 0, 50% 100%)',
                borderTop: `2px solid ${theme.envelopeBorder}`,
                transformOrigin: 'top center',
                transform: isOpen ? 'rotateX(180deg)' : 'rotateX(0deg)',
              }}
            />

            {/* 5. Digital Wax Seal with 'Hold to Break' Animation */}
            <div className="absolute top-[48px] md:top-[52px] left-1/2 -translate-x-1/2 z-40">
              <DigitalWaxSeal
                theme={theme}
                sealIcon={sealIcon}
                initials={initials}
                isOpen={isOpen}
                soundEffectsEnabled={soundEffectsEnabled}
                onBreakAndOpen={onOpen}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Under Envelope Label */}
      <p
        className="mt-3.5 text-xs font-bold tracking-wider flex items-center gap-1.5 transition-colors duration-300"
        style={{ color: theme.textHeading }}
      >
        <span style={{ color: theme.textHighlight }}>♥</span>
        <span>A Little Surprise</span>
        <span style={{ color: theme.textHighlight }}>♥</span>
      </p>

      {/* Decorative Vintage Pen & Guiding Arrow with Hold-to-Break Instructions */}
      {!isOpen && (
        <div className="relative h-28 w-full flex flex-col items-center justify-center mt-1 animate-gentle-bob">
          <div className="relative flex items-center justify-center">
            {/* Tiny pointing arrow directing to wax seal */}
            <span
              className="absolute -left-12 -top-2 text-2xl font-bold select-none animate-bounce"
              style={{ color: theme.textHighlight, transform: 'rotate(-25deg)' }}
            >
              ↙
            </span>

            {/* Crafted Calligraphy Fountain Pen */}
            <div
              className="w-3.5 h-18 rounded-t-lg rounded-b-sm relative shadow-md transition-transform duration-300"
              style={{
                background: theme.penBody,
                border: '1.5px solid #a87438',
                transform: 'rotate(24deg)',
                boxShadow: '2px 4px 8px rgba(100,50,20,0.25)',
              }}
            >
              {/* Pen cap top clip */}
              <div
                className="absolute -top-2.5 left-0.5 w-2 h-3 rounded-t-sm"
                style={{ backgroundColor: '#8a5522' }}
              />
              <div
                className="absolute top-1 right-[-4px] w-1 h-7 rounded-sm"
                style={{ backgroundColor: '#caa04e' }}
              />
              {/* Pen gold nib */}
              <span
                className="absolute -bottom-2.5 left-0.5 w-2 h-3"
                style={{
                  backgroundColor: theme.penTip,
                  clipPath: 'polygon(0 0, 100% 0, 50% 100%)',
                }}
              />
            </div>
          </div>

          {/* Explicit Hold-to-Break instruction with glowing prompt */}
          <div
            className="mt-2.5 px-3 py-1 rounded-full bg-black/20 border border-white/10 text-xs font-semibold tracking-wide flex items-center gap-1.5 shadow-sm transition-all duration-300"
            style={{ color: theme.textHeading }}
          >
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping inline-block" />
            <span>Hold wax seal to break & open</span>
            <span className="animate-soft-pulse" style={{ color: theme.textHighlight }}>
              💌
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
