import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ThemeColors, SealIconType } from '../types';
import { playWaxBreakSound, playWaxHoldTone } from '../utils/audio';
import { Sparkles } from 'lucide-react';

export interface DigitalWaxSealProps {
  theme: ThemeColors;
  sealIcon: SealIconType;
  initials: string;
  isOpen: boolean;
  soundEffectsEnabled?: boolean;
  onBreakAndOpen: () => void;
  className?: string;
}

const HOLD_DURATION_MS = 1200; // 1.2s calibrated hold duration

export const DigitalWaxSeal: React.FC<DigitalWaxSealProps> = ({
  theme,
  sealIcon,
  initials,
  isOpen,
  soundEffectsEnabled = true,
  onBreakAndOpen,
  className = '',
}) => {
  const [progress, setProgress] = useState(0);
  const [isHolding, setIsHolding] = useState(false);
  const [isBroken, setIsBroken] = useState(false);
  const [showTapHint, setShowTapHint] = useState(false);

  const startHoldTimeRef = useRef<number | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const tapTimeoutRef = useRef<number | null>(null);
  const lastSoundTimeRef = useRef<number>(0);

  // Reset state when envelope re-seals
  useEffect(() => {
    if (!isOpen) {
      setIsBroken(false);
      setProgress(0);
      setIsHolding(false);
      setShowTapHint(false);
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    }
  }, [isOpen]);

  // Clean up animation frames
  useEffect(() => {
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      if (tapTimeoutRef.current) window.clearTimeout(tapTimeoutRef.current);
    };
  }, []);

  // Frame update loop
  const updateLoop = useCallback(() => {
    if (!startHoldTimeRef.current) return;
    const now = performance.now();
    const elapsed = now - startHoldTimeRef.current;
    const nextProgress = Math.min(1, elapsed / HOLD_DURATION_MS);

    setProgress(nextProgress);

    // Subtle audio feedback during hold every ~180ms
    if (now - lastSoundTimeRef.current > 180 && nextProgress > 0.1 && nextProgress < 0.95) {
      playWaxHoldTone(nextProgress, soundEffectsEnabled);
      lastSoundTimeRef.current = now;
    }

    // Subtle haptic pulse at milestones on supported mobile devices
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      if (nextProgress >= 0.35 && nextProgress < 0.38) {
        try { navigator.vibrate(12); } catch {}
      } else if (nextProgress >= 0.7 && nextProgress < 0.73) {
        try { navigator.vibrate(18); } catch {}
      }
    }

    if (nextProgress >= 1) {
      // Seal shattered!
      setIsBroken(true);
      setIsHolding(false);
      startHoldTimeRef.current = null;

      // Haptic break pulse
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate([40, 30, 70]); } catch {}
      }

      // Play wax break audio
      playWaxBreakSound(soundEffectsEnabled);

      // Trigger envelope opening shortly after shatter burst animation
      window.setTimeout(() => {
        onBreakAndOpen();
      }, 240);
    } else {
      animFrameRef.current = requestAnimationFrame(updateLoop);
    }
  }, [soundEffectsEnabled, onBreakAndOpen]);

  // Decay loop when user releases early
  const decayProgress = useCallback(() => {
    setProgress((prev) => {
      if (prev <= 0.03) return 0;
      const next = prev * 0.85;
      animFrameRef.current = requestAnimationFrame(decayProgress);
      return next;
    });
  }, []);

  const handleStartHold = (e: React.MouseEvent | React.TouchEvent) => {
    if (isOpen || isBroken) return;
    // Don't trigger right-click
    if ('button' in e && e.button !== 0) return;

    // Prevent iOS long-press context menu / callout
    if ('touches' in e && e.cancelable) {
      e.preventDefault();
    }

    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    if (tapTimeoutRef.current) window.clearTimeout(tapTimeoutRef.current);
    setShowTapHint(false);

    setIsHolding(true);
    startHoldTimeRef.current = performance.now();
    lastSoundTimeRef.current = performance.now();

    playWaxHoldTone(0.1, soundEffectsEnabled);
    animFrameRef.current = requestAnimationFrame(updateLoop);
  };

  const handleEndHold = useCallback(() => {
    if (isBroken || isOpen) return;

    if (isHolding && startHoldTimeRef.current) {
      const elapsed = performance.now() - startHoldTimeRef.current;
      // If user tapped quickly (< 350ms) without holding to completion, show the helpful hint
      if (elapsed < 350 && progress < 0.9) {
        setShowTapHint(true);
        if (tapTimeoutRef.current) window.clearTimeout(tapTimeoutRef.current);
        tapTimeoutRef.current = window.setTimeout(() => {
          setShowTapHint(false);
        }, 2600);
      }
    }

    setIsHolding(false);
    startHoldTimeRef.current = null;
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);

    // Smoothly decay progress back to 0
    decayProgress();
  }, [isHolding, isBroken, isOpen, progress, decayProgress]);

  // Window-level release listener so shifting finger slightly outside doesn't fail
  useEffect(() => {
    if (!isHolding || isBroken || isOpen) return;

    const onWindowRelease = () => {
      handleEndHold();
    };

    window.addEventListener('mouseup', onWindowRelease);
    window.addEventListener('touchend', onWindowRelease);
    window.addEventListener('touchcancel', onWindowRelease);

    return () => {
      window.removeEventListener('mouseup', onWindowRelease);
      window.removeEventListener('touchend', onWindowRelease);
      window.removeEventListener('touchcancel', onWindowRelease);
    };
  }, [isHolding, isBroken, isOpen, handleEndHold]);

  const renderSealIcon = () => {
    switch (sealIcon) {
      case 'rose':
        return '🌹';
      case 'ring':
        return '💍';
      case 'sparkle':
        return '✦';
      case 'initials':
        return <span className="text-[11px] font-bold tracking-tight">{initials || '♥'}</span>;
      case 'heart':
      default:
        return '♥';
    }
  };

  // SVG circular progress calculation
  // Radius = 24, Circumference = 2 * PI * 24 ≈ 150.8
  const radius = 24;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - progress);

  return (
    <div className={`relative flex items-center justify-center select-none ${className}`}>
      {/* Quick Tap Helper Tooltip */}
      {showTapHint && !isBroken && !isOpen && (
        <div className="absolute -top-10 left-1/2 -translate-x-1/2 whitespace-nowrap z-50 px-2.5 py-1 rounded-full bg-stone-900/95 border border-rose-400/80 text-rose-200 text-[10px] font-bold shadow-xl animate-in fade-in slide-in-from-bottom-2 duration-200 flex items-center gap-1.5 pointer-events-none">
          <span>Press & hold to break seal!</span>
          <span>🕯️</span>
        </div>
      )}

      {/* Main Digital Wax Seal Interactive Container */}
      <div
        role="button"
        tabIndex={0}
        aria-label="Digital Wax Seal: Hold to break and open envelope"
        onMouseDown={handleStartHold}
        onTouchStart={handleStartHold}
        onKeyDown={(e) => {
          if (e.key === ' ' || e.key === 'Enter') {
            e.preventDefault();
            if (!isHolding) {
              handleStartHold(e as unknown as React.MouseEvent);
            }
          }
        }}
        onKeyUp={(e) => {
          if (e.key === ' ' || e.key === 'Enter') {
            e.preventDefault();
            handleEndHold();
          }
        }}
        className={`relative w-12 h-12 md:w-14 md:h-14 rounded-full flex items-center justify-center cursor-pointer touch-none outline-none transition-transform duration-150 ${
          isHolding && !isBroken ? 'animate-wax-tremor' : ''
        } ${isBroken ? 'pointer-events-none' : ''}`}
        style={{
          transform: isHolding
            ? `scale(${Math.max(0.91, 1 - progress * 0.08)})`
            : 'scale(1)',
          filter: isHolding
            ? `drop-shadow(0 0 ${10 + progress * 20}px ${theme.sealBg}bb)`
            : `drop-shadow(0 4px 10px ${theme.sealBg}55)`,
        }}
      >
        {/* SVG Circular Progress Ring surrounding seal */}
        <svg
          className="absolute -inset-1.5 w-[calc(100%+12px)] h-[calc(100%+12px)] pointer-events-none -rotate-90 z-20"
          viewBox="0 0 60 60"
        >
          {/* Background subtle guide ring */}
          <circle
            cx="30"
            cy="30"
            r={radius}
            fill="none"
            stroke="rgba(255, 255, 255, 0.18)"
            strokeWidth="2.5"
          />
          {/* Molten Gold/Rose Progress fill */}
          {progress > 0 && (
            <circle
              cx="30"
              cy="30"
              r={radius}
              fill="none"
              stroke="#ffd700"
              strokeWidth="3"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              style={{
                filter: 'drop-shadow(0 0 4px #ffc837)',
                transition: isHolding ? 'none' : 'stroke-dashoffset 0.15s ease-out',
              }}
            />
          )}
        </svg>

        {/* 1. Shattered Left Fragment when broken */}
        {isBroken && (
          <div
            className="absolute inset-0 rounded-full animate-wax-shatter-left pointer-events-none"
            style={{
              backgroundColor: theme.sealBg,
              clipPath: 'polygon(0 0, 52% 0, 42% 100%, 0 100%)',
              border: '1.5px solid rgba(255,255,255,0.4)',
              boxShadow: `inset 0 2px 4px rgba(255,255,255,0.4), 0 0 12px ${theme.sealBg}`,
            }}
          />
        )}

        {/* 2. Shattered Right Fragment when broken */}
        {isBroken && (
          <div
            className="absolute inset-0 rounded-full animate-wax-shatter-right pointer-events-none"
            style={{
              backgroundColor: theme.sealBg,
              clipPath: 'polygon(52% 0, 100% 0, 100% 100%, 42% 100%)',
              border: '1.5px solid rgba(255,255,255,0.4)',
              boxShadow: `inset 0 2px 4px rgba(255,255,255,0.4), 0 0 12px ${theme.sealBg}`,
            }}
          />
        )}

        {/* 3. Intact Digital Wax Seal Body (Visible before shatter) */}
        {!isBroken && (
          <div
            className="relative w-full h-full rounded-full flex items-center justify-center transition-all duration-300"
            style={{
              backgroundColor: theme.sealBg,
              color: theme.sealColor,
              boxShadow: `
                inset 0 2px 5px rgba(255,255,255,0.5),
                inset 0 -2px 6px rgba(0,0,0,0.35),
                0 4px 12px rgba(0,0,0,0.3)
              `,
              border: '1.5px solid rgba(255,255,255,0.35)',
            }}
          >
            {/* Scalloped Organic Wax Rim Details */}
            <div
              className="absolute inset-[-3px] rounded-full pointer-events-none opacity-40"
              style={{
                border: `2px dashed ${theme.sealBg}`,
                filter: 'blur(0.5px)',
              }}
            />

            {/* Glossy Curved Highlight Overlay */}
            <div
              className="absolute inset-0 rounded-full pointer-events-none"
              style={{
                background:
                  'linear-gradient(135deg, rgba(255,255,255,0.45) 0%, rgba(255,255,255,0.08) 45%, transparent 60%)',
              }}
            />

            {/* Recessed Coin Stamp Inset Circle */}
            <div
              className="w-8 h-8 md:w-9 md:h-9 rounded-full flex items-center justify-center relative shadow-inner"
              style={{
                backgroundColor: 'rgba(0, 0, 0, 0.14)',
                border: '1px solid rgba(255,255,255,0.25)',
              }}
            >
              <span className="text-sm md:text-base font-bold drop-shadow-sm flex items-center justify-center">
                {renderSealIcon()}
              </span>

              {/* Fissure Crack Layer (Spreads dynamically as progress increases) */}
              {progress > 0.22 && (
                <svg
                  className="absolute inset-0 w-full h-full pointer-events-none z-10"
                  viewBox="0 0 36 36"
                >
                  {/* Primary Center Jagged Crack */}
                  <path
                    d="M 18 3 Q 16 11, 20 18 Q 15 25, 19 33"
                    fill="none"
                    stroke="#ffd700"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    style={{
                      filter: 'drop-shadow(0 0 3px #ff8800)',
                      opacity: Math.min(1, (progress - 0.2) * 2),
                    }}
                  />

                  {/* Branching Lateral Crack (at > 50%) */}
                  {progress > 0.5 && (
                    <path
                      d="M 19 18 Q 24 14, 31 16"
                      fill="none"
                      stroke="#ffe87c"
                      strokeWidth="1.4"
                      strokeLinecap="round"
                      style={{
                        filter: 'drop-shadow(0 0 2px #ff6600)',
                        opacity: Math.min(1, (progress - 0.5) * 2.5),
                      }}
                    />
                  )}

                  {/* Second Branching Crack (at > 75%) */}
                  {progress > 0.75 && (
                    <path
                      d="M 17 22 Q 10 24, 5 28"
                      fill="none"
                      stroke="#fff2a8"
                      strokeWidth="1.4"
                      strokeLinecap="round"
                      style={{
                        filter: 'drop-shadow(0 0 3px #ff3300)',
                        opacity: Math.min(1, (progress - 0.75) * 4),
                      }}
                    />
                  )}
                </svg>
              )}
            </div>

            {/* Glowing Molten Core Particles while holding */}
            {isHolding && progress > 0.3 && (
              <div className="absolute inset-0 rounded-full pointer-events-none overflow-hidden flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-amber-200 animate-spin-slow opacity-80" />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Mini Progress Percentage Badge during active hold */}
      {isHolding && !isBroken && progress > 0.05 && (
        <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 whitespace-nowrap text-[9px] font-mono font-bold text-amber-300 bg-stone-950/80 px-2 py-0.5 rounded-full border border-amber-400/40 shadow-md">
          {Math.round(progress * 100)}%
        </div>
      )}
    </div>
  );
};
