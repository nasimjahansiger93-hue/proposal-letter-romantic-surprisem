import React, { useState, useEffect } from 'react';
import { ThemeColors, CountdownStyle, CountdownSeparator, CountdownFont } from '../types';
import { CalendarHeart, Sparkles, Heart, Edit3, Clock, Gift, PartyPopper } from 'lucide-react';

interface CountdownTimerProps {
  specialDate?: string;
  specialDateTitle?: string;
  theme: ThemeColors;
  countdownStyle?: CountdownStyle;
  countdownSeparator?: CountdownSeparator;
  countdownFont?: CountdownFont;
  countdownCelebrationMessage?: string;
  onOpenCustomizer?: () => void;
}

interface TimeRemaining {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isPast: boolean;
  totalMs: number;
}

export const CountdownTimer: React.FC<CountdownTimerProps> = ({
  specialDate,
  specialDateTitle,
  theme,
  countdownStyle = 'romantic-glass',
  countdownSeparator = 'heart',
  countdownFont = 'serif',
  countdownCelebrationMessage,
  onOpenCustomizer,
}) => {
  const [timeRemaining, setTimeRemaining] = useState<TimeRemaining>(() =>
    calculateTimeRemaining(specialDate)
  );

  useEffect(() => {
    setTimeRemaining(calculateTimeRemaining(specialDate));

    const interval = window.setInterval(() => {
      setTimeRemaining(calculateTimeRemaining(specialDate));
    }, 1000);

    return () => clearInterval(interval);
  }, [specialDate]);

  function calculateTimeRemaining(targetDateStr?: string): TimeRemaining {
    if (!targetDateStr) {
      return { days: 0, hours: 0, minutes: 0, seconds: 0, isPast: false, totalMs: 0 };
    }

    const target = new Date(targetDateStr).getTime();
    const now = Date.now();
    const diff = target - now;

    if (isNaN(target) || diff <= 0) {
      return { days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true, totalMs: diff };
    }

    const seconds = Math.floor((diff / 1000) % 60);
    const minutes = Math.floor((diff / 1000 / 60) % 60);
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    return { days, hours, minutes, seconds, isPast: false, totalMs: diff };
  }

  const formatTargetDate = (dateStr?: string) => {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
    } catch {
      return '';
    }
  };

  const formattedDate = formatTargetDate(specialDate);

  // Typography class
  const getFontClass = () => {
    switch (countdownFont) {
      case 'sans':
        return 'font-sans font-black';
      case 'mono':
        return 'font-mono font-bold tracking-tight';
      case 'serif':
      default:
        return 'font-serif font-black';
    }
  };

  const fontClass = getFontClass();

  // Style variations
  const renderContainerStyle = () => {
    switch (countdownStyle) {
      case 'vintage-parchment':
        return {
          containerClass:
            'bg-gradient-to-br from-[#fcf7ee] to-[#f4e8d3] border-2 border-[#d6be9c] text-[#5c3a21] shadow-xl',
          headerTitleClass: 'text-[#683515] font-serif font-bold',
          dateBadgeClass:
            'bg-[#ede0ca] text-[#704624] border border-[#d2bb97] font-serif',
          cardClass:
            'bg-[#ede0ca]/90 border border-[#d2bb97] shadow-inner text-[#5c3a21]',
          digitClass: 'text-[#683515]',
          labelClass: 'text-[#846243] font-serif',
          celebrationClass:
            'bg-[#e9d6b9] border-[#cfb38f] text-[#542d13]',
          iconColor: '#b46132',
        };
      case 'neon-midnight':
        return {
          containerClass:
            'bg-stone-950/90 border border-cyan-500/40 shadow-[0_0_25px_rgba(6,182,212,0.25)] backdrop-blur-md text-white',
          headerTitleClass: 'text-cyan-300 font-mono tracking-wider',
          dateBadgeClass:
            'bg-cyan-950/80 text-cyan-300 border border-cyan-500/50 font-mono',
          cardClass:
            'bg-black/90 border border-pink-500/50 shadow-[0_0_15px_rgba(244,63,94,0.2)]',
          digitClass:
            'text-pink-400 drop-shadow-[0_0_10px_rgba(244,63,94,0.8)]',
          labelClass: 'text-cyan-400 font-mono',
          celebrationClass:
            'bg-pink-950/50 border-pink-500/60 text-pink-200 shadow-[0_0_20px_rgba(244,63,94,0.3)]',
          iconColor: '#06b6d4',
        };
      case 'rose-gold':
        return {
          containerClass:
            'bg-gradient-to-r from-[#24151e] via-[#331c29] to-[#24151e] border border-[#f5a7b8]/45 shadow-[0_12px_35px_rgba(245,167,184,0.25)] text-[#ffd3dc]',
          headerTitleClass: 'text-[#ffd3dc] font-semibold tracking-wide',
          dateBadgeClass:
            'bg-[#401f30] text-[#f8b6c5] border border-[#f5a7b8]/40',
          cardClass:
            'bg-[#1a0f16]/95 border border-[#f5a7b8]/40 shadow-sm',
          digitClass: 'text-[#ffd6e0] drop-shadow-xs',
          labelClass: 'text-[#e5a2b2]',
          celebrationClass:
            'bg-[#3b1c2b] border-[#f5a7b8]/50 text-[#ffe5ec]',
          iconColor: '#f5a7b8',
        };
      case 'minimal-pill':
        return {
          containerClass:
            'bg-stone-900/60 backdrop-blur-lg border border-stone-700/60 text-stone-100 shadow-md',
          headerTitleClass: 'text-stone-200 font-medium',
          dateBadgeClass:
            'bg-stone-800 text-stone-300 border border-stone-700',
          cardClass:
            'bg-stone-800/80 border border-stone-700/80 rounded-2xl',
          digitClass: 'text-white',
          labelClass: 'text-stone-400',
          celebrationClass:
            'bg-stone-800 border-stone-700 text-stone-100',
          iconColor: theme.sealBg,
        };
      case 'romantic-glass':
      default:
        return {
          containerClass:
            'backdrop-blur-md shadow-lg border text-white transition-all duration-500',
          headerTitleClass: 'text-white font-bold tracking-wide',
          dateBadgeClass:
            'text-stone-300 bg-stone-800/90 border border-stone-700/70',
          cardClass: 'bg-stone-900/80 border border-stone-800/90 shadow-xs',
          digitClass: 'text-white',
          labelClass: 'text-stone-400',
          celebrationClass:
            'text-white',
          iconColor: theme.sealBg,
        };
    }
  };

  const styleConfig = renderContainerStyle();

  // Render Separator component
  const renderSeparator = () => {
    if (countdownSeparator === 'none') return null;

    if (countdownSeparator === 'heart') {
      return (
        <div className="flex items-center justify-center text-rose-500 animate-pulse select-none px-0.5">
          <Heart className="w-3 h-3 fill-rose-500" />
        </div>
      );
    }

    if (countdownSeparator === 'sparkle') {
      return (
        <div className="flex items-center justify-center text-amber-300 animate-pulse select-none px-0.5">
          <Sparkles className="w-3 h-3" />
        </div>
      );
    }

    if (countdownSeparator === 'colon') {
      return (
        <div className="flex items-center justify-center text-stone-400 font-bold text-base sm:text-lg select-none px-0.5">
          :
        </div>
      );
    }

    return null;
  };

  const isRomanticGlass = countdownStyle === 'romantic-glass';

  return (
    <div className="w-full max-w-[580px] mx-auto mb-6 select-none animate-in fade-in duration-500">
      <div
        className={`relative px-4 sm:px-6 py-3.5 sm:py-4 rounded-2xl ${styleConfig.containerClass} group`}
        style={
          isRomanticGlass
            ? {
                background: 'rgba(20, 27, 38, 0.72)',
                borderColor: `${theme.stageBorder}55`,
                boxShadow: `0 10px 30px rgba(0,0,0,0.3), inset 0 0 0 1px rgba(255,255,255,0.06)`,
              }
            : {}
        }
      >
        {/* Top Title Bar */}
        <div className="flex items-center justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-2 min-w-0">
            <span
              className="p-1 rounded-full flex items-center justify-center shrink-0"
              style={{
                backgroundColor: `${styleConfig.iconColor}25`,
                color: styleConfig.iconColor,
              }}
            >
              <CalendarHeart className="w-3.5 h-3.5" />
            </span>
            <span
              className={`text-xs sm:text-sm truncate ${styleConfig.headerTitleClass}`}
            >
              {specialDateTitle || 'Counting Down to Our Special Moment 💖'}
            </span>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {formattedDate && (
              <span
                className={`text-[10px] sm:text-[11px] font-semibold px-2 py-0.5 rounded-full ${styleConfig.dateBadgeClass}`}
              >
                {formattedDate}
              </span>
            )}
            {onOpenCustomizer && (
              <button
                type="button"
                onClick={onOpenCustomizer}
                className="p-1 text-stone-400 hover:text-rose-400 transition-colors cursor-pointer"
                title="Customize countdown style & date in Customizer"
              >
                <Edit3 className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>

        {/* Countdown Digits or Celebratory State */}
        {!timeRemaining.isPast ? (
          <div className="flex items-center justify-between gap-1 sm:gap-2">
            {/* Days */}
            <div
              className={`flex-1 flex flex-col items-center justify-center p-2 rounded-xl text-center ${styleConfig.cardClass}`}
            >
              <span
                className={`text-xl sm:text-2xl leading-none ${fontClass} ${
                  isRomanticGlass ? '' : styleConfig.digitClass
                }`}
                style={isRomanticGlass ? { color: theme.accentStar } : {}}
              >
                {String(timeRemaining.days).padStart(2, '0')}
              </span>
              <span
                className={`text-[9px] uppercase font-bold tracking-widest mt-1 ${styleConfig.labelClass}`}
              >
                Days
              </span>
            </div>

            {renderSeparator()}

            {/* Hours */}
            <div
              className={`flex-1 flex flex-col items-center justify-center p-2 rounded-xl text-center ${styleConfig.cardClass}`}
            >
              <span
                className={`text-xl sm:text-2xl leading-none ${fontClass} ${
                  isRomanticGlass ? 'text-white' : styleConfig.digitClass
                }`}
              >
                {String(timeRemaining.hours).padStart(2, '0')}
              </span>
              <span
                className={`text-[9px] uppercase font-bold tracking-widest mt-1 ${styleConfig.labelClass}`}
              >
                Hours
              </span>
            </div>

            {renderSeparator()}

            {/* Minutes */}
            <div
              className={`flex-1 flex flex-col items-center justify-center p-2 rounded-xl text-center ${styleConfig.cardClass}`}
            >
              <span
                className={`text-xl sm:text-2xl leading-none ${fontClass} ${
                  isRomanticGlass ? 'text-white' : styleConfig.digitClass
                }`}
              >
                {String(timeRemaining.minutes).padStart(2, '0')}
              </span>
              <span
                className={`text-[9px] uppercase font-bold tracking-widest mt-1 ${styleConfig.labelClass}`}
              >
                Mins
              </span>
            </div>

            {renderSeparator()}

            {/* Seconds (Animated pulse) */}
            <div
              className={`flex-1 flex flex-col items-center justify-center p-2 rounded-xl text-center ${styleConfig.cardClass}`}
              style={
                isRomanticGlass
                  ? { borderColor: `${theme.sealBg}55` }
                  : {}
              }
            >
              <span
                className={`text-xl sm:text-2xl leading-none transition-transform duration-200 ${fontClass} ${
                  isRomanticGlass ? '' : styleConfig.digitClass
                }`}
                style={isRomanticGlass ? { color: theme.textHighlight } : {}}
              >
                {String(timeRemaining.seconds).padStart(2, '0')}
              </span>
              <span
                className={`text-[9px] uppercase font-bold tracking-widest mt-1 ${
                  isRomanticGlass ? '' : styleConfig.labelClass
                }`}
                style={isRomanticGlass ? { color: theme.textHighlight } : {}}
              >
                Secs
              </span>
            </div>
          </div>
        ) : (
          /* Past / Reached Special Moment Celebration */
          <div
            className={`py-3 px-4 rounded-xl text-center border flex items-center justify-center gap-2 shadow-sm ${styleConfig.celebrationClass}`}
            style={
              isRomanticGlass
                ? {
                    backgroundColor: `${theme.sealBg}20`,
                    borderColor: `${theme.sealBg}55`,
                  }
                : {}
            }
          >
            <PartyPopper className="w-4 h-4 animate-bounce text-amber-300 shrink-0" />
            <span className="text-xs sm:text-sm font-bold truncate">
              {countdownCelebrationMessage ||
                'Today is Our Special Day! The magical moment has arrived 💖'}
            </span>
            <Sparkles className="w-4 h-4 animate-pulse text-amber-300 shrink-0" />
          </div>
        )}
      </div>
    </div>
  );
};
