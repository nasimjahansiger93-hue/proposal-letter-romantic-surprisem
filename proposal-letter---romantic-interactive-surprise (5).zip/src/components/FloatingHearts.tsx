import { useState, useCallback, useImperativeHandle, forwardRef } from 'react';

export interface FloatingHeartsHandle {
  burst: (count?: number) => void;
}

let heartCounter = 0;

interface HeartParticle {
  id: string;
  symbol: string;
  left: number;
  size: number;
  duration: number;
  delay: number;
  color: string;
}

interface FloatingHeartsProps {
  color?: string;
}

export const FloatingHearts = forwardRef<FloatingHeartsHandle, FloatingHeartsProps>(
  ({ color = '#e85e76' }, ref) => {
    const [hearts, setHearts] = useState<HeartParticle[]>([]);

    const burst = useCallback((count = 18) => {
      const symbols = ['♥', '✦', '💖', '✧', '🌸', '💕'];
      const newHearts: HeartParticle[] = [];

      for (let i = 0; i < count; i++) {
        heartCounter += 1;
        const id = `heart-${Date.now()}-${heartCounter}-${Math.random().toString(36).slice(2, 9)}`;
        newHearts.push({
          id,
          symbol: symbols[Math.floor(Math.random() * symbols.length)],
          left: 10 + Math.random() * 80,
          size: 14 + Math.random() * 16,
          duration: 1.8 + Math.random() * 0.8,
          delay: Math.random() * 0.4,
          color,
        });
      }

      setHearts((prev) => [...prev, ...newHearts]);

      // Remove after animation completes
      setTimeout(() => {
        setHearts((prev) => prev.filter((h) => !newHearts.some((nh) => nh.id === h.id)));
      }, 3000);
    }, [color]);

    useImperativeHandle(ref, () => ({
      burst,
    }));

    return (
      <div className="pointer-events-none absolute inset-0 overflow-hidden z-20">
        {hearts.map((h) => (
          <span
            key={h.id}
            className="animate-float-heart absolute bottom-6 select-none"
            style={{
              left: `${h.left}%`,
              fontSize: `${h.size}px`,
              color: h.color,
              animationDuration: `${h.duration}s`,
              animationDelay: `${h.delay}s`,
              filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.15))',
            }}
          >
            {h.symbol}
          </span>
        ))}
      </div>
    );
  }
);

FloatingHearts.displayName = 'FloatingHearts';
