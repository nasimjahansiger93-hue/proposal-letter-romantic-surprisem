import React, { useState, useEffect } from 'react';
import {
  ProposalConfig,
  THEMES,
  ThemeType,
  OCCASION_PRESETS,
  OccasionType,
  SealIconType,
  CountdownStyle,
  CountdownSeparator,
  CountdownFont,
} from '../types';
import {
  encodeProposalToBase64Url,
  serializeConfigToBase64,
  encodeProposalToUrl,
} from '../utils/share';
import {
  generatePolaroidDataUrl,
  POLAROID_PRESETS,
  PolaroidScene,
  PolaroidFilter,
  PolaroidPreset,
} from '../utils/polaroidGenerator';
import {
  X,
  Copy,
  Check,
  Sparkles,
  Palette,
  Heart,
  Sliders,
  Share2,
  Camera,
  Shuffle,
  Trash2,
  Upload,
  CalendarHeart,
  Clock,
  PartyPopper,
  Type,
  ExternalLink,
  Code,
  Send,
  FileCheck,
} from 'lucide-react';

interface CustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: ProposalConfig;
  onChangeConfig: (newConfig: ProposalConfig) => void;
  initialTab?: 'presets' | 'content' | 'polaroid' | 'countdown' | 'style' | 'share';
}

export const CustomizerModal: React.FC<CustomizerModalProps> = ({
  isOpen,
  onClose,
  config,
  onChangeConfig,
  initialTab = 'presets',
}) => {
  const [copied, setCopied] = useState(false);
  const [copiedBase64, setCopiedBase64] = useState(false);
  const [copiedRawBase64, setCopiedRawBase64] = useState(false);
  const [showRawBase64, setShowRawBase64] = useState(false);
  const [canShareNative, setCanShareNative] = useState(false);
  const [activeTab, setActiveTab] = useState<
    'presets' | 'content' | 'polaroid' | 'countdown' | 'style' | 'share'
  >(initialTab);

  useEffect(() => {
    if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
      setCanShareNative(true);
    }
  }, []);

  useEffect(() => {
    if (isOpen && initialTab) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  // Polaroid Generator State
  const [selectedScene, setSelectedScene] = useState<PolaroidScene>('sunset-beach');
  const [selectedFilter, setSelectedFilter] = useState<PolaroidFilter>('golden');
  const [polaroidCaption, setPolaroidCaption] = useState<string>(
    config.photoCaption || `Our favorite memory 📸`
  );
  const [dateStamp, setDateStamp] = useState<string>('08 • 14 • 24');
  const [tapeStyle, setTapeStyle] = useState<'rose-washi' | 'kraft' | 'masking' | 'none'>('rose-washi');
  const [doodle, setDoodle] = useState<'heart' | 'stars' | 'infinity' | 'none'>('heart');
  const [previewPolaroidUrl, setPreviewPolaroidUrl] = useState<string>('');

  // Generate initial preview on mount or when tab opens
  useEffect(() => {
    if (isOpen) {
      if (config.photoUrl) {
        setPreviewPolaroidUrl(config.photoUrl);
      } else {
        const url = generatePolaroidDataUrl({
          scene: selectedScene,
          filter: selectedFilter,
          caption: polaroidCaption,
          dateStamp,
          tapeStyle,
          doodle,
        });
        setPreviewPolaroidUrl(url);
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleGeneratePolaroid = () => {
    const dataUrl = generatePolaroidDataUrl({
      scene: selectedScene,
      filter: selectedFilter,
      caption: polaroidCaption,
      dateStamp,
      tapeStyle,
      doodle,
    });
    setPreviewPolaroidUrl(dataUrl);
    onChangeConfig({
      ...config,
      photoUrl: dataUrl,
      photoCaption: polaroidCaption,
    });
  };

  const handleApplyPreset = (preset: PolaroidPreset) => {
    setSelectedScene(preset.scene);
    setSelectedFilter(preset.filter);
    setPolaroidCaption(preset.caption);
    setDateStamp(preset.dateStamp);

    const dataUrl = generatePolaroidDataUrl({
      scene: preset.scene,
      filter: preset.filter,
      caption: preset.caption,
      dateStamp: preset.dateStamp,
      tapeStyle,
      doodle,
    });
    setPreviewPolaroidUrl(dataUrl);
    onChangeConfig({
      ...config,
      photoUrl: dataUrl,
      photoCaption: preset.caption,
    });
  };

  const handleRandomizePolaroid = () => {
    const scenes: PolaroidScene[] = [
      'sunset-beach',
      'starry-night',
      'cherry-blossom',
      'candlelight',
      'golden-mountains',
      'fairy-lights',
    ];
    const filters: PolaroidFilter[] = ['vintage', 'golden', 'pastel', 'sepia', 'vibrant', 'film-noir'];
    const randomScene = scenes[Math.floor(Math.random() * scenes.length)];
    const randomFilter = filters[Math.floor(Math.random() * filters.length)];
    const randomCaptions = [
      'Forever starts with you ✨',
      'Our favorite sunset together 🌅',
      'You are my greatest adventure 💫',
      'The moment I fell for you 🌸',
      'Under the stars with my love 🌌',
      'Every day with you is special ♥',
    ];
    const randomCap = randomCaptions[Math.floor(Math.random() * randomCaptions.length)];

    setSelectedScene(randomScene);
    setSelectedFilter(randomFilter);
    setPolaroidCaption(randomCap);

    const dataUrl = generatePolaroidDataUrl({
      scene: randomScene,
      filter: randomFilter,
      caption: randomCap,
      dateStamp,
      tapeStyle,
      doodle,
    });
    setPreviewPolaroidUrl(dataUrl);
    onChangeConfig({
      ...config,
      photoUrl: dataUrl,
      photoCaption: randomCap,
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (result) {
          setPreviewPolaroidUrl(result);
          onChangeConfig({
            ...config,
            photoUrl: result,
            photoCaption: polaroidCaption || file.name,
          });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    setPreviewPolaroidUrl('');
    onChangeConfig({
      ...config,
      photoUrl: '',
      photoCaption: '',
    });
  };

  const handlePresetSelect = (key: OccasionType) => {
    const preset = OCCASION_PRESETS[key];
    onChangeConfig({
      ...config,
      occasionType: key,
      eyebrowText: preset.eyebrow,
      headlinePrefix: preset.prefix,
      headlineHighlight: preset.highlight,
      messageBody: preset.body,
      yesButtonText: preset.yesText,
      maybeButtonText: preset.maybeText,
      yesResponseText: preset.yesReply,
    });
  };

  const base64Url = encodeProposalToBase64Url(config);
  const rawBase64 = serializeConfigToBase64(config);

  const handleCopyBase64Link = () => {
    navigator.clipboard.writeText(base64Url);
    setCopiedBase64(true);
    setCopied(true);
    setTimeout(() => {
      setCopiedBase64(false);
      setCopied(false);
    }, 2400);
  };

  const handleCopyRawBase64 = () => {
    navigator.clipboard.writeText(rawBase64);
    setCopiedRawBase64(true);
    setTimeout(() => setCopiedRawBase64(false), 2400);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Proposal Letter for ${config.recipientName || 'You'}`,
          text: `A little something special from ${config.senderName || 'someone who loves you'}... 💌`,
          url: base64Url,
        });
      } catch {
        handleCopyBase64Link();
      }
    } else {
      handleCopyBase64Link();
    }
  };

  const handleCopyLink = () => {
    handleCopyBase64Link();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl max-h-[90vh] bg-stone-900 border border-stone-700 text-stone-100 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-stone-800 flex items-center justify-between bg-stone-950/60">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-rose-400" />
            <h2 className="text-base sm:text-lg font-bold text-white">Personalize Proposal Letter</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-stone-800 bg-stone-950/30 px-3 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('presets')}
            className={`px-3 py-2.5 text-xs font-semibold flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'presets'
                ? 'border-rose-400 text-rose-400'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Presets</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('content')}
            className={`px-3 py-2.5 text-xs font-semibold flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'content'
                ? 'border-rose-400 text-rose-400'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <Heart className="w-3.5 h-3.5" />
            <span>Names & Words</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('polaroid')}
            className={`px-3 py-2.5 text-xs font-semibold flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'polaroid'
                ? 'border-rose-400 text-rose-400'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Polaroid Photo</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('countdown')}
            className={`px-3 py-2.5 text-xs font-semibold flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'countdown'
                ? 'border-rose-400 text-rose-400'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Live Countdown</span>
            {config.showCountdown !== false && (
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-pulse ml-0.5" />
            )}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('style')}
            className={`px-3 py-2.5 text-xs font-semibold flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'style'
                ? 'border-rose-400 text-rose-400'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Themes & Seal</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('share')}
            className={`px-3 py-2.5 text-xs font-semibold flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'share'
                ? 'border-rose-400 text-rose-400'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Share Link</span>
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5 text-xs">
          {/* TAB 1: PRESETS */}
          {activeTab === 'presets' && (
            <div className="space-y-4">
              <p className="text-stone-400 text-xs">
                Pick an occasion preset to instantly adapt the proposal wording:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {(Object.keys(OCCASION_PRESETS) as OccasionType[]).map((key) => {
                  const preset = OCCASION_PRESETS[key];
                  const isSelected = config.occasionType === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => handlePresetSelect(key)}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex items-start gap-3 ${
                        isSelected
                          ? 'border-rose-400 bg-rose-500/10 text-white ring-1 ring-rose-400'
                          : 'border-stone-800 bg-stone-800/40 text-stone-300 hover:border-stone-700 hover:bg-stone-800/70'
                      }`}
                    >
                      <span className="text-xl">{preset.icon}</span>
                      <div>
                        <div className="font-semibold text-xs text-white">{preset.name}</div>
                        <div className="text-[11px] text-stone-400 line-clamp-1 mt-0.5">
                          {preset.highlight}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Names Input Section */}
              <div className="pt-3 border-t border-stone-800 grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-300 font-semibold mb-1">Recipient Name</label>
                  <input
                    type="text"
                    value={config.recipientName}
                    onChange={(e) => onChangeConfig({ ...config, recipientName: e.target.value })}
                    placeholder="e.g. Sarah"
                    className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-white placeholder-stone-500 focus:outline-rose-400"
                  />
                </div>
                <div>
                  <label className="block text-stone-300 font-semibold mb-1">Your Name (Sender)</label>
                  <input
                    type="text"
                    value={config.senderName}
                    onChange={(e) => onChangeConfig({ ...config, senderName: e.target.value })}
                    placeholder="e.g. Alex"
                    className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-white placeholder-stone-500 focus:outline-rose-400"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: CONTENT */}
          {activeTab === 'content' && (
            <div className="space-y-4">
              <div>
                <label className="block text-stone-300 font-semibold mb-1">Top Eyebrow Text</label>
                <input
                  type="text"
                  value={config.eyebrowText}
                  onChange={(e) => onChangeConfig({ ...config, eyebrowText: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-white focus:outline-rose-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-300 font-semibold mb-1">Headline Prefix</label>
                  <input
                    type="text"
                    value={config.headlinePrefix}
                    onChange={(e) => onChangeConfig({ ...config, headlinePrefix: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-white focus:outline-rose-400"
                  />
                </div>
                <div>
                  <label className="block text-stone-300 font-semibold mb-1">
                    Headline Highlight (Italicized)
                  </label>
                  <input
                    type="text"
                    value={config.headlineHighlight}
                    onChange={(e) =>
                      onChangeConfig({ ...config, headlineHighlight: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-white focus:outline-rose-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-300 font-semibold mb-1">Proposal Letter Message</label>
                <textarea
                  rows={4}
                  value={config.messageBody}
                  onChange={(e) => onChangeConfig({ ...config, messageBody: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-white focus:outline-rose-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-300 font-semibold mb-1">"Yes" Button Text</label>
                  <input
                    type="text"
                    value={config.yesButtonText}
                    onChange={(e) => onChangeConfig({ ...config, yesButtonText: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-white focus:outline-rose-400"
                  />
                </div>
                <div>
                  <label className="block text-stone-300 font-semibold mb-1">"Maybe / No" Button Text</label>
                  <input
                    type="text"
                    value={config.maybeButtonText}
                    onChange={(e) => onChangeConfig({ ...config, maybeButtonText: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-white focus:outline-rose-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-300 font-semibold mb-1">
                  Celebration Reply when "Yes" is clicked
                </label>
                <input
                  type="text"
                  value={config.yesResponseText}
                  onChange={(e) => onChangeConfig({ ...config, yesResponseText: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-white focus:outline-rose-400"
                />
              </div>

              {/* Countdown Shortcut Card */}
              <div className="pt-4 border-t border-stone-800">
                <div className="flex items-center justify-between p-3.5 rounded-xl bg-stone-800/50 border border-stone-700/60">
                  <div className="flex items-start gap-2.5">
                    <Clock className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-semibold text-white flex items-center gap-2">
                        <span>Live Countdown to Special Date</span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                            config.showCountdown !== false
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : 'bg-stone-700 text-stone-400'
                          }`}
                        >
                          {config.showCountdown !== false ? 'Active' : 'Hidden'}
                        </span>
                      </div>
                      <div className="text-[11px] text-stone-400 mt-0.5">
                        {config.specialDateTitle || "Until Our Valentine's Day 💖"} •{' '}
                        {config.specialDate
                          ? new Date(config.specialDate).toLocaleDateString(undefined, {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric',
                            })
                          : 'No date set'}
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveTab('countdown')}
                    className="px-3 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 font-semibold border border-rose-500/40 transition-colors text-xs flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <span>Customize Timer</span>
                    <Sparkles className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: POLAROID PHOTO GENERATOR */}
          {activeTab === 'polaroid' && (
            <div className="space-y-5">
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-rose-950/40 to-stone-900 border border-rose-900/40 flex items-start gap-3">
                <Camera className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-white text-xs sm:text-sm">Romantic Polaroid Studio</h4>
                  <p className="text-stone-300 text-[11px] mt-0.5 leading-relaxed">
                    Generate an artistic, vintage Polaroid keepsake to tuck directly into your proposal letter.
                    Pick a scene, filter, and romantic handwritten caption!
                  </p>
                </div>
              </div>

              {/* Generator Studio & Preview Area */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-5">
                {/* Left Controls (7 cols) */}
                <div className="sm:col-span-7 space-y-3.5">
                  {/* Scene Selector */}
                  <div>
                    <label className="block text-stone-300 font-semibold mb-1.5 flex items-center justify-between">
                      <span>Artistic Scene</span>
                      <button
                        type="button"
                        onClick={handleRandomizePolaroid}
                        className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer font-medium"
                      >
                        <Shuffle className="w-3 h-3" />
                        <span>Surprise Me</span>
                      </button>
                    </label>
                    <div className="grid grid-cols-2 gap-1.5">
                      {[
                        { id: 'sunset-beach', name: 'Sunset Beach', icon: '🌅' },
                        { id: 'starry-night', name: 'Starry Starlight', icon: '🌌' },
                        { id: 'cherry-blossom', name: 'Cherry Blossom', icon: '🌸' },
                        { id: 'candlelight', name: 'Candlelight', icon: '🕯️' },
                        { id: 'golden-mountains', name: 'Mountain Dawn', icon: '⛰️' },
                        { id: 'fairy-lights', name: 'Fairy Lights', icon: '💫' },
                      ].map((scene) => (
                        <button
                          key={scene.id}
                          type="button"
                          onClick={() => {
                            setSelectedScene(scene.id as PolaroidScene);
                          }}
                          className={`px-2.5 py-2 rounded-lg border text-left flex items-center gap-2 cursor-pointer transition-all ${
                            selectedScene === scene.id
                              ? 'border-rose-400 bg-rose-500/20 text-white'
                              : 'border-stone-800 bg-stone-800/40 text-stone-300 hover:bg-stone-800/80'
                          }`}
                        >
                          <span>{scene.icon}</span>
                          <span className="truncate font-medium">{scene.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Filter Selector */}
                  <div>
                    <label className="block text-stone-300 font-semibold mb-1.5">Film Filter & Tone</label>
                    <div className="flex flex-wrap gap-1.5">
                      {[
                        { id: 'golden', label: 'Golden Hour' },
                        { id: 'vintage', label: 'Vintage 35mm' },
                        { id: 'pastel', label: 'Pastel Dream' },
                        { id: 'sepia', label: 'Warm Sepia' },
                        { id: 'film-noir', label: 'B&W Film' },
                        { id: 'vibrant', label: 'Vibrant' },
                      ].map((filter) => (
                        <button
                          key={filter.id}
                          type="button"
                          onClick={() => setSelectedFilter(filter.id as PolaroidFilter)}
                          className={`px-2.5 py-1.5 rounded-lg border text-[11px] font-medium cursor-pointer transition-colors ${
                            selectedFilter === filter.id
                              ? 'border-rose-400 bg-rose-500/20 text-white'
                              : 'border-stone-700 bg-stone-800 text-stone-400 hover:text-white'
                          }`}
                        >
                          {filter.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Caption & Date Stamp */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-stone-300 font-semibold mb-1">
                        Handwritten Caption
                      </label>
                      <input
                        type="text"
                        value={polaroidCaption}
                        onChange={(e) => setPolaroidCaption(e.target.value)}
                        placeholder="e.g. Our sunset walk 🌊"
                        className="w-full px-2.5 py-1.5 rounded-lg bg-stone-800 border border-stone-700 text-white focus:outline-rose-400 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-300 font-semibold mb-1">
                        Date Stamp (Optional)
                      </label>
                      <input
                        type="text"
                        value={dateStamp}
                        onChange={(e) => setDateStamp(e.target.value)}
                        placeholder="e.g. 08 • 14 • 24"
                        className="w-full px-2.5 py-1.5 rounded-lg bg-stone-800 border border-stone-700 text-white focus:outline-rose-400 text-xs font-mono"
                      />
                    </div>
                  </div>

                  {/* Tape Style & Corner Doodle */}
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-stone-300 font-semibold mb-1">Tape Style</label>
                      <select
                        value={tapeStyle}
                        onChange={(e) => setTapeStyle(e.target.value as any)}
                        className="w-full px-2 py-1.5 rounded-lg bg-stone-800 border border-stone-700 text-white focus:outline-rose-400 text-xs"
                      >
                        <option value="rose-washi">Rose Gold Washi</option>
                        <option value="kraft">Kraft Paper</option>
                        <option value="masking">Translucent</option>
                        <option value="none">No Tape</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-stone-300 font-semibold mb-1">Corner Doodle</label>
                      <select
                        value={doodle}
                        onChange={(e) => setDoodle(e.target.value as any)}
                        className="w-full px-2 py-1.5 rounded-lg bg-stone-800 border border-stone-700 text-white focus:outline-rose-400 text-xs"
                      >
                        <option value="heart">Heart ♥</option>
                        <option value="stars">Stars ✦</option>
                        <option value="infinity">Infinity ∞</option>
                        <option value="none">None</option>
                      </select>
                    </div>
                  </div>

                  {/* Generate & Apply Button */}
                  <div className="pt-2 flex gap-2">
                    <button
                      type="button"
                      onClick={handleGeneratePolaroid}
                      className="flex-1 py-2 rounded-xl bg-gradient-to-r from-rose-500 to-rose-600 hover:from-rose-600 hover:to-rose-700 text-white font-semibold flex items-center justify-center gap-1.5 shadow-md cursor-pointer transition-all"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Generate & Attach to Letter</span>
                    </button>
                  </div>
                </div>

                {/* Right Preview Column (5 cols) */}
                <div className="sm:col-span-5 flex flex-col items-center justify-center p-3 rounded-xl bg-stone-950/70 border border-stone-800">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400 mb-2">
                    Polaroid Preview
                  </span>

                  {previewPolaroidUrl ? (
                    <div className="relative group max-w-[170px] transform -rotate-1 transition-transform duration-300 hover:rotate-0">
                      <img
                        src={previewPolaroidUrl}
                        alt="Polaroid preview"
                        className="w-full rounded-sm shadow-xl border border-stone-300/40"
                      />
                    </div>
                  ) : (
                    <div className="w-36 h-44 rounded border border-dashed border-stone-700 flex flex-col items-center justify-center text-stone-500 text-center p-2">
                      <Camera className="w-6 h-6 mb-1 opacity-50" />
                      <span className="text-[10px]">No photo attached</span>
                    </div>
                  )}

                  {config.photoUrl && (
                    <button
                      type="button"
                      onClick={handleRemovePhoto}
                      className="mt-3 text-[11px] text-red-400 hover:text-red-300 flex items-center gap-1 cursor-pointer font-medium"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Remove from Letter</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Instant Romantic Presets Gallery */}
              <div className="pt-3 border-t border-stone-800">
                <label className="block text-stone-300 font-semibold mb-2">
                  Quick Romantic Presets (One-click Apply)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {POLAROID_PRESETS.map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => handleApplyPreset(preset)}
                      className="p-2.5 rounded-xl border border-stone-800 bg-stone-800/40 hover:bg-stone-800 hover:border-rose-400/60 text-left transition-all cursor-pointer group"
                    >
                      <div className="font-bold text-white text-[11px] group-hover:text-rose-300 truncate">
                        {preset.title}
                      </div>
                      <div className="text-[10px] text-stone-400 line-clamp-1 mt-0.5">
                        {preset.caption}
                      </div>
                      <span className="inline-block mt-1 text-[9px] font-semibold text-rose-400">
                        Apply Preset →
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Or Custom Upload Option */}
              <div className="pt-3 border-t border-stone-800 flex flex-wrap items-center justify-between gap-3">
                <div className="text-stone-400 text-[11px]">
                  Want to use your own couple photo instead?
                </div>
                <label className="px-3 py-1.5 rounded-lg border border-stone-700 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-medium flex items-center gap-1.5 cursor-pointer transition-colors">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload Image File</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          )}



          {/* TAB: LIVE COUNTDOWN TO SPECIAL DATE */}
          {activeTab === 'countdown' && (
            <div className="space-y-5">
              {/* Top Banner */}
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-rose-950/40 via-stone-900 to-stone-950 border border-rose-900/40 flex items-start gap-3">
                <CalendarHeart className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <h4 className="font-bold text-white text-xs sm:text-sm flex items-center justify-between">
                    <span>Special Date Countdown Studio</span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                        config.showCountdown !== false
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-stone-800 text-stone-400'
                      }`}
                    >
                      {config.showCountdown !== false ? 'Live on Page' : 'Disabled'}
                    </span>
                  </h4>
                  <p className="text-stone-300 text-[11px] mt-0.5 leading-relaxed">
                    Showcase a live, animated countdown timer below your proposal header. Perfect
                    for Valentine’s Day, your future wedding, a milestone anniversary, or your next romantic date.
                  </p>
                </div>
              </div>

              {/* Master Enable/Disable Switch */}
              <div className="flex items-center justify-between p-3.5 rounded-xl bg-stone-800/40 border border-stone-700/60">
                <div>
                  <div className="font-semibold text-white text-xs sm:text-sm">
                    Show Live Countdown on Letter Page
                  </div>
                  <div className="text-[11px] text-stone-400">
                    When enabled, the countdown renders right between the header and the envelope.
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.showCountdown !== false}
                    onChange={(e) =>
                      onChangeConfig({ ...config, showCountdown: e.target.checked })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-stone-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-500"></div>
                </label>
              </div>

              {/* Live Preview Box */}
              {config.showCountdown !== false && (
                <div className="p-4 rounded-xl bg-stone-950/80 border border-stone-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400">
                      Live Timer Preview
                    </span>
                    <span className="text-[10px] text-rose-300/80 font-mono">
                      Theme: {config.countdownStyle || 'romantic-glass'}
                    </span>
                  </div>

                  {/* Visual Preview Container */}
                  <div
                    className={`p-3.5 rounded-xl border text-center transition-all ${
                      config.countdownStyle === 'vintage-parchment'
                        ? 'bg-[#fcf7ee] border-[#d6be9c] text-[#5c3a21]'
                        : config.countdownStyle === 'neon-midnight'
                        ? 'bg-black border-cyan-500/50 text-white shadow-[0_0_15px_rgba(6,182,212,0.2)]'
                        : config.countdownStyle === 'rose-gold'
                        ? 'bg-gradient-to-r from-[#24151e] to-[#331c29] border-[#f5a7b8]/40 text-[#ffd3dc]'
                        : config.countdownStyle === 'minimal-pill'
                        ? 'bg-stone-900/70 border-stone-700 text-stone-100'
                        : 'bg-stone-900/90 border-stone-700/80 text-white'
                    }`}
                  >
                    <div className="text-xs font-bold mb-2 flex items-center justify-center gap-1.5">
                      <CalendarHeart className="w-3.5 h-3.5 text-rose-400" />
                      <span>{config.specialDateTitle || "Until Our Valentine's Day 💖"}</span>
                    </div>

                    <div className="flex items-center justify-center gap-1 sm:gap-2">
                      {['03 Days', '14 Hours', '25 Mins', '42 Secs'].map((unit, idx, arr) => {
                        const [val, label] = unit.split(' ');
                        const fontStyleClass =
                          config.countdownFont === 'sans'
                            ? 'font-sans font-extrabold'
                            : config.countdownFont === 'mono'
                            ? 'font-mono font-bold tracking-tight'
                            : 'font-serif font-black';

                        return (
                          <React.Fragment key={unit}>
                            <div
                              className={`px-2.5 py-1.5 rounded-lg border flex flex-col items-center min-w-[52px] ${
                                config.countdownStyle === 'vintage-parchment'
                                  ? 'bg-[#ede0ca] border-[#d2bb97] text-[#683515]'
                                  : config.countdownStyle === 'neon-midnight'
                                  ? 'bg-stone-950 border-pink-500/50 text-pink-400 shadow-[0_0_8px_rgba(244,63,94,0.3)]'
                                  : config.countdownStyle === 'rose-gold'
                                  ? 'bg-[#180e14] border-[#f5a7b8]/40 text-[#ffd6e0]'
                                  : 'bg-stone-800/80 border-stone-700/80 text-white'
                              }`}
                            >
                              <span className={`text-base sm:text-lg leading-none ${fontStyleClass}`}>
                                {val}
                              </span>
                              <span className="text-[8px] uppercase tracking-wider opacity-70 mt-0.5">
                                {label}
                              </span>
                            </div>

                            {idx < arr.length - 1 && config.countdownSeparator !== 'none' && (
                              <div className="text-xs px-0.5">
                                {config.countdownSeparator === 'heart' ||
                                !config.countdownSeparator ? (
                                  <Heart className="w-3 h-3 fill-rose-500 text-rose-500 animate-pulse" />
                                ) : config.countdownSeparator === 'sparkle' ? (
                                  <Sparkles className="w-3 h-3 text-amber-300" />
                                ) : (
                                  <span className="font-bold text-stone-400">:</span>
                                )}
                              </div>
                            )}
                          </React.Fragment>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* Event Title & Inspiration Chips */}
              <div className="space-y-2">
                <label className="block text-stone-300 font-semibold">
                  Event Title & Romantic Wording
                </label>
                <input
                  type="text"
                  value={config.specialDateTitle || ''}
                  onChange={(e) =>
                    onChangeConfig({ ...config, specialDateTitle: e.target.value })
                  }
                  placeholder="e.g. Until Our Valentine's Day 💖"
                  className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-white placeholder-stone-500 focus:outline-rose-400 text-xs"
                />

                {/* Quick Romantic Title Inspiration Chips */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {[
                    { label: "💖 Valentine's Day", text: "Until Our Valentine's Day 💖" },
                    { label: '💍 Wedding Day', text: 'Counting Down to Our Wedding 💍' },
                    { label: '🥂 1 Year Anniversary', text: 'Celebrating 1 Year of Love 🥂' },
                    { label: '🌹 She Says Yes', text: 'The Moment You Say Yes 🌹' },
                    { label: '✈️ Romantic Vacation', text: 'Until Our Romantic Getaway ✈️' },
                    { label: '🎂 Sweet Birthday', text: 'Until Your Magical Birthday 🎂' },
                  ].map((chip) => (
                    <button
                      key={chip.label}
                      type="button"
                      onClick={() =>
                        onChangeConfig({
                          ...config,
                          specialDateTitle: chip.text,
                        })
                      }
                      className="px-2 py-1 rounded-full bg-stone-800 hover:bg-stone-700 border border-stone-700 text-stone-300 hover:text-white text-[10px] font-medium transition-colors cursor-pointer"
                    >
                      {chip.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Target Date & Quick Date Presets */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-300 font-semibold mb-1">
                    Target Date & Time
                  </label>
                  <input
                    type="datetime-local"
                    value={config.specialDate || ''}
                    onChange={(e) =>
                      onChangeConfig({ ...config, specialDate: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-white focus:outline-rose-400 text-xs font-mono"
                  />
                  <div className="text-[10px] text-stone-400 mt-1 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-rose-400" />
                    <span>Timer updates in real-time each second</span>
                  </div>
                </div>

                <div>
                  <label className="block text-stone-300 font-semibold mb-1">
                    Quick Date Presets
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() =>
                        onChangeConfig({
                          ...config,
                          specialDate: '2027-02-14T00:00',
                          specialDateTitle: "Until Our Valentine's Day 💖",
                        })
                      }
                      className="px-2 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-[10px] font-medium border border-stone-700 truncate cursor-pointer text-left"
                    >
                      💖 Valentine's Day
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const in30Days = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
                        onChangeConfig({
                          ...config,
                          specialDate: in30Days.toISOString().slice(0, 16),
                          specialDateTitle: 'Counting down to Our Big Day 💍',
                        });
                      }}
                      className="px-2 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-[10px] font-medium border border-stone-700 truncate cursor-pointer text-left"
                    >
                      💍 In 30 Days
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const in100Days = new Date(Date.now() + 100 * 24 * 60 * 60 * 1000);
                        onChangeConfig({
                          ...config,
                          specialDate: in100Days.toISOString().slice(0, 16),
                          specialDateTitle: 'Celebrating 100 Days of Happiness 💕',
                        });
                      }}
                      className="px-2 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-[10px] font-medium border border-stone-700 truncate cursor-pointer text-left"
                    >
                      🥂 In 100 Days
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const nextYear = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);
                        onChangeConfig({
                          ...config,
                          specialDate: nextYear.toISOString().slice(0, 16),
                          specialDateTitle: 'Happy 1 Year Anniversary 🌹',
                        });
                      }}
                      className="px-2 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-[10px] font-medium border border-stone-700 truncate cursor-pointer text-left"
                    >
                      🌟 1 Year from Today
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000);
                        onChangeConfig({
                          ...config,
                          specialDate: tomorrow.toISOString().slice(0, 16),
                          specialDateTitle: 'Until Tomorrow Evening 🕯️',
                        });
                      }}
                      className="px-2 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-[10px] font-medium border border-stone-700 truncate cursor-pointer text-left"
                    >
                      ⏳ Tomorrow (24h)
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const in7Days = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
                        onChangeConfig({
                          ...config,
                          specialDate: in7Days.toISOString().slice(0, 16),
                          specialDateTitle: 'Until Our Romantic Weekend 🍷',
                        });
                      }}
                      className="px-2 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-[10px] font-medium border border-stone-700 truncate cursor-pointer text-left"
                    >
                      🍷 Next Weekend
                    </button>
                  </div>
                </div>
              </div>

              {/* Visual Themes Selection */}
              <div>
                <label className="block text-stone-300 font-semibold mb-2">
                  Timer Visual Theme
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    {
                      id: 'romantic-glass' as CountdownStyle,
                      name: 'Romantic Glass',
                      desc: 'Frosted dark glass with theme glow',
                      badge: 'bg-stone-800 text-rose-300 border border-rose-500/30',
                    },
                    {
                      id: 'vintage-parchment' as CountdownStyle,
                      name: 'Vintage Parchment',
                      desc: 'Antique warm paper & walnut ink',
                      badge: 'bg-[#ede0ca] text-[#683515] border border-[#d2bb97]',
                    },
                    {
                      id: 'neon-midnight' as CountdownStyle,
                      name: 'Neon Midnight',
                      desc: 'Obsidian with cyan & pink glow',
                      badge: 'bg-black text-cyan-300 border border-cyan-500/50',
                    },
                    {
                      id: 'rose-gold' as CountdownStyle,
                      name: 'Rose Gold Luxury',
                      desc: 'Metallic champagne rose aura',
                      badge: 'bg-[#2a1721] text-[#ffd6e0] border border-[#f5a7b8]/40',
                    },
                    {
                      id: 'minimal-pill' as CountdownStyle,
                      name: 'Minimalist Pill',
                      desc: 'Modern floating clean pill',
                      badge: 'bg-stone-800 text-white border border-stone-600',
                    },
                  ].map((thm) => {
                    const isSelected =
                      (config.countdownStyle || 'romantic-glass') === thm.id;
                    return (
                      <button
                        key={thm.id}
                        type="button"
                        onClick={() =>
                          onChangeConfig({ ...config, countdownStyle: thm.id })
                        }
                        className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                          isSelected
                            ? 'border-rose-400 bg-rose-500/10 text-white ring-1 ring-rose-400'
                            : 'border-stone-800 bg-stone-800/40 text-stone-300 hover:border-stone-700'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-xs">{thm.name}</span>
                          <span
                            className={`text-[9px] px-1.5 py-0.5 rounded-md font-mono ${thm.badge}`}
                          >
                            Preview
                          </span>
                        </div>
                        <div className="text-[10px] text-stone-400 leading-tight">
                          {thm.desc}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Separators & Typography Settings */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                {/* Separators */}
                <div>
                  <label className="block text-stone-300 font-semibold mb-2">
                    Digit Separators
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      {
                        id: 'heart' as CountdownSeparator,
                        label: '♥ Heart',
                        sub: 'Pulsing mini heart',
                      },
                      {
                        id: 'sparkle' as CountdownSeparator,
                        label: '✦ Sparkle',
                        sub: 'Star sparkle glow',
                      },
                      {
                        id: 'colon' as CountdownSeparator,
                        label: ': Colon',
                        sub: 'Classic digital clock',
                      },
                      {
                        id: 'none' as CountdownSeparator,
                        label: 'None',
                        sub: 'Clean spaced boxes',
                      },
                    ].map((sep) => {
                      const isSelected =
                        (config.countdownSeparator || 'heart') === sep.id;
                      return (
                        <button
                          key={sep.id}
                          type="button"
                          onClick={() =>
                            onChangeConfig({ ...config, countdownSeparator: sep.id })
                          }
                          className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                            isSelected
                              ? 'border-rose-400 bg-rose-500/10 text-white ring-1 ring-rose-400'
                              : 'border-stone-800 bg-stone-800/40 text-stone-300 hover:border-stone-700'
                          }`}
                        >
                          <div className="font-bold text-xs">{sep.label}</div>
                          <div className="text-[10px] text-stone-400">{sep.sub}</div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Typography / Font */}
                <div>
                  <label className="block text-stone-300 font-semibold mb-2 flex items-center gap-1.5">
                    <Type className="w-3.5 h-3.5 text-rose-400" />
                    <span>Digit Typography</span>
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      {
                        id: 'serif' as CountdownFont,
                        label: 'Serif',
                        fontClass: 'font-serif',
                        sub: 'Romantic',
                      },
                      {
                        id: 'sans' as CountdownFont,
                        label: 'Sans',
                        fontClass: 'font-sans font-bold',
                        sub: 'Modern',
                      },
                      {
                        id: 'mono' as CountdownFont,
                        label: 'Mono',
                        fontClass: 'font-mono font-bold',
                        sub: 'Digital',
                      },
                    ].map((fnt) => {
                      const isSelected =
                        (config.countdownFont || 'serif') === fnt.id;
                      return (
                        <button
                          key={fnt.id}
                          type="button"
                          onClick={() =>
                            onChangeConfig({ ...config, countdownFont: fnt.id })
                          }
                          className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                            isSelected
                              ? 'border-rose-400 bg-rose-500/10 text-white ring-1 ring-rose-400'
                              : 'border-stone-800 bg-stone-800/40 text-stone-300 hover:border-stone-700'
                          }`}
                        >
                          <div className={`text-base leading-none mb-1 ${fnt.fontClass}`}>
                            14
                          </div>
                          <div className="text-[10px] font-semibold text-stone-300">
                            {fnt.label}
                          </div>
                          <div className="text-[9px] text-stone-400">{fnt.sub}</div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Celebration Message When Target Date is Reached */}
              <div className="space-y-2 pt-2 border-t border-stone-800">
                <label className="block text-stone-300 font-semibold flex items-center gap-1.5">
                  <PartyPopper className="w-3.5 h-3.5 text-amber-300" />
                  <span>Celebration Message when Timer Reaches Zero</span>
                </label>
                <input
                  type="text"
                  value={
                    config.countdownCelebrationMessage ||
                    'Today is Our Special Day! The magical moment has arrived 💖'
                  }
                  onChange={(e) =>
                    onChangeConfig({
                      ...config,
                      countdownCelebrationMessage: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-white focus:outline-rose-400 text-xs"
                />

                <div className="flex flex-wrap gap-1.5">
                  {[
                    'Today is Our Special Day! The magical moment has arrived 💖',
                    'The wait is over! Forever starts today! 💍✨',
                    'Happy Anniversary sweetheart! Here to infinity 🥂🌹',
                    'We are finally together! Best day ever! 🎉❤️',
                  ].map((msg) => (
                    <button
                      key={msg}
                      type="button"
                      onClick={() =>
                        onChangeConfig({
                          ...config,
                          countdownCelebrationMessage: msg,
                        })
                      }
                      className="px-2 py-1 rounded-md bg-stone-800 hover:bg-stone-700 text-stone-400 hover:text-stone-200 border border-stone-700 text-[10px] truncate max-w-xs cursor-pointer"
                    >
                      {msg}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: STYLE & THEME */}
          {activeTab === 'style' && (
            <div className="space-y-5">
              {/* Color Themes */}
              <div>
                <label className="block text-stone-300 font-semibold mb-2">Palette Theme</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {(Object.keys(THEMES) as ThemeType[]).map((themeKey) => {
                    const theme = THEMES[themeKey];
                    const isSelected = config.theme === themeKey;
                    return (
                      <button
                        key={themeKey}
                        type="button"
                        onClick={() => onChangeConfig({ ...config, theme: themeKey })}
                        className={`p-2.5 rounded-xl border flex items-center justify-between text-left transition-all cursor-pointer ${
                          isSelected
                            ? 'border-rose-400 bg-rose-500/10 text-white ring-1 ring-rose-400'
                            : 'border-stone-800 bg-stone-800/40 text-stone-300 hover:border-stone-700'
                        }`}
                      >
                        <span className="font-medium text-xs">{theme.name}</span>
                        <div className="flex items-center gap-1">
                          <span
                            className="w-4 h-4 rounded-full border border-black/20"
                            style={{ backgroundColor: theme.sealBg }}
                          />
                          <span
                            className="w-4 h-4 rounded-full border border-black/20"
                            style={{ backgroundColor: theme.envelopeFlap }}
                          />
                          <span
                            className="w-4 h-4 rounded-full border border-black/20"
                            style={{ backgroundColor: theme.letterBg }}
                          />
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Wax Seal Style */}
              <div>
                <label className="block text-stone-300 font-semibold mb-2">Wax Seal Stamp</label>
                <div className="flex flex-wrap gap-2">
                  {(
                    [
                      { id: 'heart', label: 'Heart ♥' },
                      { id: 'rose', label: 'Rose 🌹' },
                      { id: 'ring', label: 'Ring 💍' },
                      { id: 'sparkle', label: 'Sparkle ✦' },
                      { id: 'initials', label: 'Initials' },
                    ] as { id: SealIconType; label: string }[]
                  ).map((seal) => (
                    <button
                      key={seal.id}
                      type="button"
                      onClick={() => onChangeConfig({ ...config, sealIcon: seal.id })}
                      className={`px-3 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer transition-colors ${
                        config.sealIcon === seal.id
                          ? 'border-rose-400 bg-rose-500/20 text-rose-300'
                          : 'border-stone-700 bg-stone-800 text-stone-300 hover:bg-stone-700'
                      }`}
                    >
                      {seal.label}
                    </button>
                  ))}
                </div>

                {config.sealIcon === 'initials' && (
                  <div className="mt-2 max-w-[140px]">
                    <label className="block text-stone-400 text-[11px] mb-0.5">Custom Initials</label>
                    <input
                      type="text"
                      maxLength={4}
                      value={config.initials}
                      onChange={(e) => onChangeConfig({ ...config, initials: e.target.value.toUpperCase() })}
                      className="w-full px-2 py-1 text-center font-bold text-xs rounded bg-stone-800 border border-stone-700 text-white"
                      placeholder="S+A"
                    />
                  </div>
                )}
              </div>

              {/* Interactive Gameplay Settings */}
              <div className="pt-3 border-t border-stone-800 space-y-3">
                <div className="flex items-center justify-between p-3 rounded-xl bg-stone-800/40 border border-stone-700/60">
                  <div>
                    <div className="font-semibold text-white">Playful "Runaway No" Button</div>
                    <div className="text-[11px] text-stone-400">
                      The "No" button will playfully dodge the cursor when hovered!
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={config.runawayNoButton}
                    onChange={(e) =>
                      onChangeConfig({ ...config, runawayNoButton: e.target.checked })
                    }
                    className="w-4 h-4 accent-rose-500 cursor-pointer"
                  />
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-stone-800/40 border border-stone-700/60">
                  <div>
                    <div className="font-semibold text-white">Sound Effects</div>
                    <div className="text-[11px] text-stone-400">
                      Gentle paper rustle, romantic chimes, and playful boops.
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={config.soundEffectsEnabled}
                    onChange={(e) =>
                      onChangeConfig({ ...config, soundEffectsEnabled: e.target.checked })
                    }
                    className="w-4 h-4 accent-rose-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: SHARE LINK (BASE64 ENCODED) */}
          {activeTab === 'share' && (
            <div className="space-y-4">
              {/* Header Banner */}
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-rose-950/40 via-stone-900 to-stone-950 border border-rose-900/40 flex items-start gap-3">
                <Share2 className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="font-bold text-white text-xs sm:text-sm">
                      Base64 Serialized Proposal Setup
                    </h4>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30 flex items-center gap-1">
                      <FileCheck className="w-3 h-3" />
                      <span>Ready to Share</span>
                    </span>
                  </div>
                  <p className="text-stone-300 text-[11px] mt-1 leading-relaxed">
                    Your entire customized proposal configuration—including names, customized letter,
                    countdown to your special date, polaroid memory, and wax seal—is serialized into a
                    compact, self-contained Base64 URL string.
                  </p>
                </div>
              </div>

              {/* Base64 Encoded Share Link Card */}
              <div className="p-4 rounded-xl bg-stone-800/60 border border-stone-700/60 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-stone-300 font-semibold text-xs flex items-center gap-1.5">
                    <span>Base64 Encoded Share Link</span>
                    <span className="text-[10px] text-stone-500 font-normal">
                      (~{(rawBase64.length / 1024).toFixed(1)} KB payload)
                    </span>
                  </label>
                  <span className="text-[10px] text-rose-300/80 font-mono">
                    ?p={rawBase64.slice(0, 10)}...
                  </span>
                </div>

                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="relative flex-1">
                    <input
                      type="text"
                      readOnly
                      value={base64Url}
                      onClick={(e) => (e.target as HTMLInputElement).select()}
                      className="w-full px-3 py-2 rounded-lg bg-stone-900/90 border border-stone-700 text-stone-200 text-xs font-mono select-all truncate focus:outline-rose-400"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={handleCopyBase64Link}
                      className="flex-1 sm:flex-initial px-4 py-2 rounded-lg bg-gradient-to-r from-rose-500 to-rose-600 hover:from-rose-600 hover:to-rose-700 text-white font-semibold flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer whitespace-nowrap"
                    >
                      {copiedBase64 ? (
                        <>
                          <Check className="w-4 h-4 text-white" />
                          <span>Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" />
                          <span>Copy Link</span>
                        </>
                      )}
                    </button>

                    {canShareNative && (
                      <button
                        type="button"
                        onClick={handleNativeShare}
                        className="px-3 py-2 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold border border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                        title="Share via device share menu"
                      >
                        <Send className="w-3.5 h-3.5 text-rose-400" />
                        <span className="hidden sm:inline text-xs">Share</span>
                      </button>
                    )}

                    <a
                      href={base64Url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-2 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold border border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer text-xs"
                      title="Test the link in a new tab"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-stone-400" />
                      <span className="hidden sm:inline">Test</span>
                    </a>
                  </div>
                </div>

                {/* Copied Feedback Banner */}
                {copiedBase64 && (
                  <div className="p-2.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs text-center font-medium animate-in fade-in flex items-center justify-center gap-1.5">
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>
                      Base64 share link copied! Paste it in WhatsApp, Messenger, or text message.
                    </span>
                  </div>
                )}
              </div>

              {/* Configuration Payload Summary Details */}
              <div className="p-3.5 rounded-xl bg-stone-900/60 border border-stone-800 space-y-2">
                <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400">
                  Serialized Setup Highlights
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                  <div className="p-2 rounded-lg bg-stone-800/40 border border-stone-800">
                    <span className="text-stone-400 block text-[9px] uppercase">To Recipient</span>
                    <span className="font-semibold text-white truncate block">
                      {config.recipientName || 'Sarah'}
                    </span>
                  </div>
                  <div className="p-2 rounded-lg bg-stone-800/40 border border-stone-800">
                    <span className="text-stone-400 block text-[9px] uppercase">From Sender</span>
                    <span className="font-semibold text-white truncate block">
                      {config.senderName || 'Alex'}
                    </span>
                  </div>
                  <div className="p-2 rounded-lg bg-stone-800/40 border border-stone-800">
                    <span className="text-stone-400 block text-[9px] uppercase">Theme</span>
                    <span className="font-semibold text-rose-300 truncate block">
                      {config.theme}
                    </span>
                  </div>
                  <div className="p-2 rounded-lg bg-stone-800/40 border border-stone-800">
                    <span className="text-stone-400 block text-[9px] uppercase">Live Countdown</span>
                    <span className="font-semibold text-emerald-300 truncate block">
                      {config.showCountdown !== false && config.specialDate ? 'Active' : 'Hidden'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Raw Base64 Payload Inspector / Copy Feature */}
              <div className="border border-stone-800 rounded-xl overflow-hidden bg-stone-950/40">
                <button
                  type="button"
                  onClick={() => setShowRawBase64(!showRawBase64)}
                  className="w-full px-3.5 py-2.5 flex items-center justify-between text-left text-xs font-semibold text-stone-300 hover:text-white hover:bg-stone-800/40 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <Code className="w-3.5 h-3.5 text-rose-400" />
                    <span>Inspect Raw Base64 Payload</span>
                  </div>
                  <span className="text-[10px] text-stone-500 font-mono">
                    {showRawBase64 ? '▲ Hide' : '▼ Show'}
                  </span>
                </button>

                {showRawBase64 && (
                  <div className="p-3 border-t border-stone-800 space-y-2 bg-stone-950/70">
                    <p className="text-[10px] text-stone-400">
                      This is the raw Base64 string representation of your serialized config JSON:
                    </p>
                    <textarea
                      readOnly
                      rows={3}
                      value={rawBase64}
                      className="w-full px-2.5 py-2 rounded-lg bg-stone-900 border border-stone-700 text-stone-400 text-[10px] font-mono select-all focus:outline-none"
                    />
                    <div className="flex justify-end">
                      <button
                        type="button"
                        onClick={handleCopyRawBase64}
                        className="px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-medium flex items-center gap-1.5 border border-stone-700 transition-colors cursor-pointer"
                      >
                        {copiedRawBase64 ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Payload Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy Raw Base64</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-stone-800 bg-stone-950/60 flex items-center justify-between">
          <p className="text-[11px] text-stone-500">Changes apply live in the background.</p>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-semibold text-xs transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
