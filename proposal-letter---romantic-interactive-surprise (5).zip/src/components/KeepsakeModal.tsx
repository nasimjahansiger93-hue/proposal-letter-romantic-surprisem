import React from 'react';
import { ProposalConfig, ThemeColors } from '../types';
import { X, Printer, Heart, Award } from 'lucide-react';

interface KeepsakeModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: ProposalConfig;
  theme: ThemeColors;
}

export const KeepsakeModal: React.FC<KeepsakeModalProps> = ({
  isOpen,
  onClose,
  config,
  theme,
}) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const currentDate = new Date().toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-300">
      <div className="relative w-full max-w-lg bg-[#fffdf9] text-stone-800 rounded-2xl shadow-2xl overflow-hidden border-8 border-[#ebd5b3]">
        {/* Close Button */}
        <button
          onClick={onClose}
          type="button"
          className="absolute top-3 right-3 p-1.5 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-500 hover:text-stone-800 transition-colors z-20 cursor-pointer"
          aria-label="Close keepsake"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Certificate Frame Inner Border */}
        <div className="p-6 sm:p-8 m-2 border-2 border-dashed border-[#d8be96] rounded-xl flex flex-col items-center text-center relative bg-gradient-to-b from-[#fffefc] to-[#fbf7ee]">
          {/* Top Vintage Ornament */}
          <div className="flex items-center gap-2 mb-2 text-[#b08b52]">
            <span>✦</span>
            <span className="w-12 h-px bg-[#b08b52]" />
            <Award className="w-5 h-5 text-[#b08b52]" />
            <span className="w-12 h-px bg-[#b08b52]" />
            <span>✦</span>
          </div>

          <p className="text-[10px] tracking-[0.3em] uppercase text-stone-500 font-semibold mb-1">
            Official Keepsake Certificate
          </p>

          <h3
            className="text-2xl sm:text-3xl font-bold text-stone-800 tracking-tight mb-2"
            style={{ fontFamily: 'var(--font-serif)' }}
          >
            She / He Said Yes! 💖
          </h3>

          <p className="text-xs text-stone-500 italic mb-6">
            Commemorating a beautiful question answered from the heart
          </p>

          {/* Names Display */}
          <div className="w-full py-4 border-y border-[#eddcc4] my-2 bg-stone-50/50 rounded-lg">
            <p className="text-xs uppercase tracking-wider text-stone-400 font-medium">To My Beloved</p>
            <p
              className="text-2xl sm:text-3xl font-bold my-1 text-[#b54a5f]"
              style={{ fontFamily: 'var(--font-hand)' }}
            >
              {config.recipientName}
            </p>

            <p className="text-xs italic text-stone-600 max-w-sm mx-auto my-2">
              "{config.headlinePrefix} {config.headlineHighlight}"
            </p>

            <p className="text-xs uppercase tracking-wider text-stone-400 font-medium mt-3">From</p>
            <p
              className="text-xl sm:text-2xl font-bold text-[#b54a5f]"
              style={{ fontFamily: 'var(--font-hand)' }}
            >
              {config.senderName}
            </p>
          </div>

          {/* Date & Wax Seal Badge */}
          <div className="w-full flex items-center justify-between mt-6 px-4">
            <div className="text-left">
              <p className="text-[10px] uppercase tracking-wider text-stone-400">Date Sealed</p>
              <p className="text-xs font-semibold text-stone-700">{currentDate}</p>
            </div>

            {/* Simulated Wax Seal on Certificate */}
            <div
              className="w-12 h-12 rounded-full flex items-center justify-center shadow-md transform rotate-6 border-2 border-white/40"
              style={{ backgroundColor: theme.sealBg, color: theme.sealColor }}
            >
              <Heart className="w-6 h-6 fill-current" />
            </div>

            <div className="text-right">
              <p className="text-[10px] uppercase tracking-wider text-stone-400">Status</p>
              <p className="text-xs font-semibold text-emerald-700">Accepted Forever ✨</p>
            </div>
          </div>

          {/* Actions */}
          <div className="mt-8 flex flex-wrap gap-3 justify-center no-print">
            <button
              onClick={handlePrint}
              type="button"
              className="px-4 py-2 rounded-full bg-stone-800 hover:bg-stone-900 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save Keepsake</span>
            </button>
            <button
              onClick={onClose}
              type="button"
              className="px-4 py-2 rounded-full bg-stone-200 hover:bg-stone-300 text-stone-700 text-xs font-semibold transition-colors cursor-pointer"
            >
              Back to Letter
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
