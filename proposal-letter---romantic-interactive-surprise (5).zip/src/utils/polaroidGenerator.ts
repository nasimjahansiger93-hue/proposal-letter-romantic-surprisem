/**
 * Generates custom romantic "Polaroid" style placeholder images
 * using client-side HTML5 Canvas with artistic gradients, silhouettes,
 * film grain, bokeh, and vintage filters.
 */

export type PolaroidScene =
  | 'sunset-beach'
  | 'starry-night'
  | 'cherry-blossom'
  | 'candlelight'
  | 'golden-mountains'
  | 'fairy-lights';

export type PolaroidFilter = 'vintage' | 'golden' | 'sepia' | 'pastel' | 'film-noir' | 'vibrant';

export interface PolaroidOptions {
  scene: PolaroidScene;
  filter: PolaroidFilter;
  caption: string;
  dateStamp?: string;
  tapeStyle?: 'rose-washi' | 'kraft' | 'masking' | 'none';
  doodle?: 'heart' | 'stars' | 'infinity' | 'none';
}

export interface PolaroidPreset {
  id: string;
  title: string;
  scene: PolaroidScene;
  filter: PolaroidFilter;
  caption: string;
  dateStamp: string;
  description: string;
}

export const POLAROID_PRESETS: PolaroidPreset[] = [
  {
    id: 'sunset-walk',
    title: 'Sunset by the Ocean',
    scene: 'sunset-beach',
    filter: 'golden',
    caption: 'Our favorite sunset walk 🌊🌅',
    dateStamp: '07 • 21 • 24',
    description: 'Golden hour waves, warm sea breeze, and endless horizons.',
  },
  {
    id: 'stargazing',
    title: 'Under the Stars',
    scene: 'starry-night',
    filter: 'vintage',
    caption: 'Wishing on shooting stars with you ✨🌌',
    dateStamp: '08 • 14 • 24',
    description: 'Midnight indigo sky, glowing moon, and sparkling constellations.',
  },
  {
    id: 'sakura-spring',
    title: 'Cherry Blossom Bloom',
    scene: 'cherry-blossom',
    filter: 'pastel',
    caption: 'Spring days in full bloom 🌸🍃',
    dateStamp: '04 • 09 • 24',
    description: 'Soft blush petals drifting in a gentle spring breeze.',
  },
  {
    id: 'candlelight-dinner',
    title: 'Candlelight & Roses',
    scene: 'candlelight',
    filter: 'golden',
    caption: 'Just you, me, and candlelight 🕯️🍷',
    dateStamp: '11 • 08 • 24',
    description: 'Warm glowing embers, quiet laughter, and red rose petals.',
  },
  {
    id: 'mountain-sunrise',
    title: 'Sunrise in the Mountains',
    scene: 'golden-mountains',
    filter: 'vibrant',
    caption: 'Top of the world with you ⛰️✨',
    dateStamp: '09 • 18 • 24',
    description: 'Misty pine valleys and golden morning rays breaking over peaks.',
  },
  {
    id: 'fairy-lights-magic',
    title: 'Twilight & Fairy Lights',
    scene: 'fairy-lights',
    filter: 'vintage',
    caption: 'Every moment with you is magic 💫',
    dateStamp: '12 • 24 • 24',
    description: 'Glowing warm bokeh, golden fireflies, and romantic twilight.',
  },
];

/**
 * Renders a full romantic Polaroid picture onto a canvas and returns a PNG Data URL
 */
export function generatePolaroidDataUrl(options: PolaroidOptions): string {
  if (typeof document === 'undefined') return '';

  const canvas = document.createElement('canvas');
  // Classic polaroid ratio: 400x490
  const width = 440;
  const height = 530;
  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // 1. Draw Polaroid Paper Card (Off-white parchment with soft shadow)
  ctx.fillStyle = '#fdfbf7';
  ctx.fillRect(0, 0, width, height);

  // Subtle border / aged paper rim
  ctx.strokeStyle = '#ebe3d5';
  ctx.lineWidth = 1;
  ctx.strokeRect(0.5, 0.5, width - 1, height - 1);

  // 2. Photo Area (390 x 390 square photo inset)
  const photoMarginX = 25;
  const photoMarginY = 25;
  const photoWidth = width - photoMarginX * 2; // 390
  const photoHeight = 390;

  ctx.save();
  // Clip to photo area
  ctx.beginPath();
  ctx.rect(photoMarginX, photoMarginY, photoWidth, photoHeight);
  ctx.clip();

  // Draw Scene inside Photo Area
  drawScene(ctx, photoMarginX, photoMarginY, photoWidth, photoHeight, options.scene);

  // Apply Filter Tint / Vignette
  applyFilter(ctx, photoMarginX, photoMarginY, photoWidth, photoHeight, options.filter);

  // Add Film Grain / Noise
  addFilmGrain(ctx, photoMarginX, photoMarginY, photoWidth, photoHeight);

  // Inner Photo Border/Shadow
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.15)';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(photoMarginX, photoMarginY, photoWidth, photoHeight);

  ctx.restore();

  // 3. Optional Vintage Orange Date Stamp on bottom-right of photo
  if (options.dateStamp) {
    ctx.save();
    ctx.font = 'bold 13px "Courier New", monospace';
    ctx.fillStyle = 'rgba(255, 140, 0, 0.88)';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
    ctx.shadowBlur = 4;
    ctx.textAlign = 'right';
    ctx.fillText(options.dateStamp, photoMarginX + photoWidth - 14, photoMarginY + photoHeight - 14);
    ctx.restore();
  }

  // 4. Handwritten Caption on Bottom White Area
  if (options.caption) {
    ctx.save();
    ctx.font = 'bold 22px "Caveat", "Brush Script MT", cursive, sans-serif';
    ctx.fillStyle = '#42332e';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const captionY = photoMarginY + photoHeight + (height - (photoMarginY + photoHeight)) / 2 - 2;
    ctx.fillText(options.caption, width / 2, captionY);
    ctx.restore();
  }

  // 5. Optional Small Doodle in corner of the polaroid margin
  if (options.doodle && options.doodle !== 'none') {
    ctx.save();
    ctx.font = '16px sans-serif';
    ctx.fillStyle = '#e85e76';
    ctx.textAlign = 'right';
    if (options.doodle === 'heart') {
      ctx.fillText('♥', width - 28, height - 20);
    } else if (options.doodle === 'stars') {
      ctx.fillText('✦ ✧', width - 28, height - 20);
    } else if (options.doodle === 'infinity') {
      ctx.fillText('∞', width - 28, height - 20);
    }
    ctx.restore();
  }

  // 6. Optional Tape on Top
  if (options.tapeStyle && options.tapeStyle !== 'none') {
    ctx.save();
    const tapeW = 80;
    const tapeH = 22;
    const tapeX = (width - tapeW) / 2;
    const tapeY = 6;

    if (options.tapeStyle === 'rose-washi') {
      ctx.fillStyle = 'rgba(235, 142, 160, 0.72)';
    } else if (options.tapeStyle === 'kraft') {
      ctx.fillStyle = 'rgba(210, 180, 140, 0.75)';
    } else {
      ctx.fillStyle = 'rgba(240, 240, 240, 0.65)';
    }

    ctx.translate(tapeX + tapeW / 2, tapeY + tapeH / 2);
    ctx.rotate(-0.03);
    ctx.fillRect(-tapeW / 2, -tapeH / 2, tapeW, tapeH);
    ctx.strokeStyle = 'rgba(0,0,0,0.06)';
    ctx.strokeRect(-tapeW / 2, -tapeH / 2, tapeW, tapeH);
    ctx.restore();
  }

  return canvas.toDataURL('image/png');
}

/**
 * Draws the specific artistic romantic scene
 */
function drawScene(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  scene: PolaroidScene
) {
  switch (scene) {
    case 'sunset-beach': {
      // Sky gradient
      const skyGrad = ctx.createLinearGradient(x, y, x, y + h * 0.7);
      skyGrad.addColorStop(0, '#532b5e');
      skyGrad.addColorStop(0.3, '#b83b5e');
      skyGrad.addColorStop(0.65, '#f08a5d');
      skyGrad.addColorStop(1, '#ffdf80');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(x, y, w, h * 0.7);

      // Glowing Golden Sun
      const sunX = x + w * 0.52;
      const sunY = y + h * 0.52;
      const sunGrad = ctx.createRadialGradient(sunX, sunY, 5, sunX, sunY, 80);
      sunGrad.addColorStop(0, '#ffffff');
      sunGrad.addColorStop(0.25, '#fff1a8');
      sunGrad.addColorStop(0.6, 'rgba(255, 180, 80, 0.5)');
      sunGrad.addColorStop(1, 'rgba(255, 140, 60, 0)');
      ctx.fillStyle = sunGrad;
      ctx.beginPath();
      ctx.arc(sunX, sunY, 80, 0, Math.PI * 2);
      ctx.fill();

      // Clouds
      ctx.fillStyle = 'rgba(255, 230, 200, 0.25)';
      ctx.beginPath();
      ctx.ellipse(x + w * 0.3, y + h * 0.35, 70, 14, 0, 0, Math.PI * 2);
      ctx.ellipse(x + w * 0.75, y + h * 0.42, 90, 16, 0, 0, Math.PI * 2);
      ctx.fill();

      // Ocean Water with golden reflection
      const oceanGrad = ctx.createLinearGradient(x, y + h * 0.65, x, y + h);
      oceanGrad.addColorStop(0, '#d16a50');
      oceanGrad.addColorStop(0.4, '#80344b');
      oceanGrad.addColorStop(1, '#3b1836');
      ctx.fillStyle = oceanGrad;
      ctx.fillRect(x, y + h * 0.65, w, h * 0.35);

      // Sun reflection shimmer on water
      ctx.fillStyle = 'rgba(255, 240, 180, 0.35)';
      for (let i = 0; i < 18; i++) {
        const lineY = y + h * 0.66 + i * (h * 0.018);
        const lineWidth = (i + 4) * 5;
        const lineX = sunX - lineWidth / 2 + (Math.sin(i) * 6);
        ctx.fillRect(lineX, lineY, lineWidth, 2);
      }

      // Beach shoreline silhouette
      ctx.fillStyle = '#1c0d1c';
      ctx.beginPath();
      ctx.moveTo(x, y + h * 0.88);
      ctx.bezierCurveTo(x + w * 0.4, y + h * 0.84, x + w * 0.7, y + h * 0.86, x + w, y + h * 0.82);
      ctx.lineTo(x + w, y + h);
      ctx.lineTo(x, y + h);
      ctx.closePath();
      ctx.fill();

      // Two Lovers Silhouette holding hands
      drawLoversSilhouette(ctx, x + w * 0.5, y + h * 0.82, 0.68);
      break;
    }

    case 'starry-night': {
      // Midnight Sky
      const skyGrad = ctx.createLinearGradient(x, y, x, y + h);
      skyGrad.addColorStop(0, '#0a0d1e');
      skyGrad.addColorStop(0.5, '#151c36');
      skyGrad.addColorStop(1, '#241b38');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(x, y, w, h);

      // Nebula glow
      const nebGrad = ctx.createRadialGradient(x + w * 0.6, y + h * 0.35, 20, x + w * 0.6, y + h * 0.35, 160);
      nebGrad.addColorStop(0, 'rgba(155, 89, 182, 0.35)');
      nebGrad.addColorStop(0.5, 'rgba(52, 152, 219, 0.2)');
      nebGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = nebGrad;
      ctx.fillRect(x, y, w, h);

      // Crescent Moon with soft halo
      const moonX = x + w * 0.78;
      const moonY = y + h * 0.22;
      const moonHalo = ctx.createRadialGradient(moonX, moonY, 10, moonX, moonY, 40);
      moonHalo.addColorStop(0, 'rgba(255, 255, 220, 0.3)');
      moonHalo.addColorStop(1, 'transparent');
      ctx.fillStyle = moonHalo;
      ctx.beginPath();
      ctx.arc(moonX, moonY, 40, 0, Math.PI * 2);
      ctx.fill();

      // Crescent Moon shape
      ctx.fillStyle = '#fffce0';
      ctx.beginPath();
      ctx.arc(moonX, moonY, 18, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#151c36';
      ctx.beginPath();
      ctx.arc(moonX - 7, moonY - 4, 16, 0, Math.PI * 2);
      ctx.fill();

      // Stars
      ctx.fillStyle = '#ffffff';
      for (let i = 0; i < 90; i++) {
        const starX = x + (Math.sin(i * 123.45) * 0.5 + 0.5) * w;
        const starY = y + (Math.cos(i * 67.89) * 0.5 + 0.5) * (h * 0.75);
        const starSize = (i % 3 === 0) ? 2 : 1;
        ctx.globalAlpha = 0.4 + (i % 5) * 0.14;
        ctx.fillRect(starX, starY, starSize, starSize);
      }
      ctx.globalAlpha = 1.0;

      // Shooting Star Streak
      const shootGrad = ctx.createLinearGradient(x + w * 0.2, y + h * 0.18, x + w * 0.45, y + h * 0.28);
      shootGrad.addColorStop(0, 'rgba(255,255,255,0)');
      shootGrad.addColorStop(0.7, 'rgba(255,240,200,0.4)');
      shootGrad.addColorStop(1, 'rgba(255,255,255,0.9)');
      ctx.strokeStyle = shootGrad;
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(x + w * 0.15, y + h * 0.14);
      ctx.lineTo(x + w * 0.45, y + h * 0.28);
      ctx.stroke();

      // Star sparkle head
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(x + w * 0.45, y + h * 0.28, 2.5, 0, Math.PI * 2);
      ctx.fill();

      // Hill & Tree silhouette
      ctx.fillStyle = '#060810';
      ctx.beginPath();
      ctx.moveTo(x, y + h * 0.82);
      ctx.quadraticCurveTo(x + w * 0.5, y + h * 0.72, x + w, y + h * 0.84);
      ctx.lineTo(x + w, y + h);
      ctx.lineTo(x, y + h);
      ctx.closePath();
      ctx.fill();

      // Pine trees
      drawPineTree(ctx, x + w * 0.12, y + h * 0.76, 24);
      drawPineTree(ctx, x + w * 0.18, y + h * 0.78, 18);
      drawPineTree(ctx, x + w * 0.85, y + h * 0.79, 22);

      // Two Lovers looking at the sky
      drawLoversSilhouette(ctx, x + w * 0.52, y + h * 0.74, 0.65);
      break;
    }

    case 'cherry-blossom': {
      // Soft pastel spring sky
      const skyGrad = ctx.createLinearGradient(x, y, x, y + h);
      skyGrad.addColorStop(0, '#f8e5ec');
      skyGrad.addColorStop(0.4, '#fff0f5');
      skyGrad.addColorStop(1, '#fde2e4');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(x, y, w, h);

      // Sun flare / soft morning orb
      const sunGrad = ctx.createRadialGradient(x + w * 0.8, y + h * 0.25, 10, x + w * 0.8, y + h * 0.25, 120);
      sunGrad.addColorStop(0, 'rgba(255, 255, 255, 0.8)');
      sunGrad.addColorStop(0.4, 'rgba(255, 228, 225, 0.5)');
      sunGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = sunGrad;
      ctx.fillRect(x, y, w, h);

      // Elegant Tree Branch
      ctx.strokeStyle = '#4a2c2a';
      ctx.lineWidth = 4;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(x, y + h * 0.15);
      ctx.bezierCurveTo(x + w * 0.35, y + h * 0.25, x + w * 0.55, y + h * 0.18, x + w * 0.85, y + h * 0.3);
      ctx.stroke();

      // Sub-branches
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(x + w * 0.35, y + h * 0.23);
      ctx.bezierCurveTo(x + w * 0.45, y + h * 0.32, x + w * 0.5, y + h * 0.38, x + w * 0.6, y + h * 0.4);
      ctx.stroke();

      // Cherry Blossoms Clusters
      const petalColors = ['#ffccd5', '#ffb3c1', '#ff8fa3', '#fff0f3'];
      const flowerPositions = [
        [0.2, 0.18], [0.26, 0.14], [0.33, 0.22], [0.42, 0.21], [0.48, 0.17],
        [0.55, 0.26], [0.63, 0.28], [0.72, 0.31], [0.52, 0.36], [0.58, 0.42],
        [0.38, 0.29], [0.46, 0.26]
      ];

      flowerPositions.forEach(([fx, fy]) => {
        const cx = x + w * fx;
        const cy = y + h * fy;
        for (let p = 0; p < 5; p++) {
          const angle = (p * Math.PI * 2) / 5;
          const px = cx + Math.cos(angle) * 7;
          const py = cy + Math.sin(angle) * 7;
          ctx.fillStyle = petalColors[p % petalColors.length];
          ctx.beginPath();
          ctx.ellipse(px, py, 6, 4, angle, 0, Math.PI * 2);
          ctx.fill();
        }
        // Center pistil
        ctx.fillStyle = '#ff4d6d';
        ctx.beginPath();
        ctx.arc(cx, cy, 2, 0, Math.PI * 2);
        ctx.fill();
      });

      // Drifting Petals
      for (let i = 0; i < 22; i++) {
        const petX = x + (Math.sin(i * 37) * 0.5 + 0.5) * w;
        const petY = y + (Math.cos(i * 83) * 0.5 + 0.5) * h;
        const angle = i * 0.6;
        ctx.fillStyle = 'rgba(255, 179, 193, 0.85)';
        ctx.beginPath();
        ctx.ellipse(petX, petY, 5, 3, angle, 0, Math.PI * 2);
        ctx.fill();
      }

      // Soft grassy ground
      ctx.fillStyle = '#7a8450';
      ctx.beginPath();
      ctx.moveTo(x, y + h * 0.88);
      ctx.quadraticCurveTo(x + w * 0.5, y + h * 0.85, x + w, y + h * 0.88);
      ctx.lineTo(x + w, y + h);
      ctx.lineTo(x, y + h);
      ctx.closePath();
      ctx.fill();

      // Couple sitting together under the tree
      drawLoversSitting(ctx, x + w * 0.48, y + h * 0.86, 0.7);
      break;
    }

    case 'candlelight': {
      // Cozy dark restaurant/cafe background
      const darkGrad = ctx.createRadialGradient(x + w * 0.5, y + h * 0.45, 30, x + w * 0.5, y + h * 0.45, 200);
      darkGrad.addColorStop(0, '#59291b');
      darkGrad.addColorStop(0.5, '#2e120b');
      darkGrad.addColorStop(1, '#110604');
      ctx.fillStyle = darkGrad;
      ctx.fillRect(x, y, w, h);

      // Bokeh Circles (Fairy lights & chandeliers in background)
      const bokehColors = ['rgba(255, 215, 120, 0.25)', 'rgba(255, 180, 80, 0.2)', 'rgba(255, 240, 200, 0.15)'];
      for (let i = 0; i < 18; i++) {
        const bx = x + (Math.sin(i * 59) * 0.5 + 0.5) * w;
        const by = y + (Math.cos(i * 41) * 0.5 + 0.5) * (h * 0.6);
        const br = 12 + (i % 4) * 8;
        ctx.fillStyle = bokehColors[i % bokehColors.length];
        ctx.beginPath();
        ctx.arc(bx, by, br, 0, Math.PI * 2);
        ctx.fill();
      }

      // Rustic table surface
      const tableGrad = ctx.createLinearGradient(x, y + h * 0.65, x, y + h);
      tableGrad.addColorStop(0, '#2d160e');
      tableGrad.addColorStop(1, '#180a06');
      ctx.fillStyle = tableGrad;
      ctx.fillRect(x, y + h * 0.65, w, h * 0.35);

      // Candle in glass holder
      const candleX = x + w * 0.5;
      const candleY = y + h * 0.62;

      // Candle glow
      const glow = ctx.createRadialGradient(candleX, candleY - 14, 4, candleX, candleY - 14, 90);
      glow.addColorStop(0, 'rgba(255, 235, 160, 0.95)');
      glow.addColorStop(0.3, 'rgba(255, 150, 40, 0.45)');
      glow.addColorStop(1, 'transparent');
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(candleX, candleY - 14, 90, 0, Math.PI * 2);
      ctx.fill();

      // Flame
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.ellipse(candleX, candleY - 12, 3, 7, 0, 0, Math.PI * 2);
      ctx.fill();

      // Glass Holder
      ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.strokeStyle = 'rgba(255, 220, 180, 0.4)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(candleX - 16, candleY, 32, 42, 4);
      ctx.fill();
      ctx.stroke();

      // Two Wine Glasses Toasting
      drawWineGlass(ctx, candleX - 45, candleY + 10, -0.15);
      drawWineGlass(ctx, candleX + 45, candleY + 10, 0.15);

      // Rose Petals on Table
      ctx.fillStyle = '#b31e3b';
      for (let i = 0; i < 9; i++) {
        const rpx = x + w * 0.25 + (i * 26);
        const rpy = y + h * 0.8 + (Math.sin(i) * 12);
        ctx.beginPath();
        ctx.ellipse(rpx, rpy, 6, 4, i * 0.5, 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    }

    case 'golden-mountains': {
      // Alpine Morning Sky
      const skyGrad = ctx.createLinearGradient(x, y, x, y + h * 0.6);
      skyGrad.addColorStop(0, '#f9d5bb');
      skyGrad.addColorStop(0.5, '#fdebd2');
      skyGrad.addColorStop(1, '#fffaeb');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(x, y, w, h * 0.6);

      // Distant Morning Sun
      const sunGrad = ctx.createRadialGradient(x + w * 0.35, y + h * 0.3, 10, x + w * 0.35, y + h * 0.3, 110);
      sunGrad.addColorStop(0, '#ffffff');
      sunGrad.addColorStop(0.4, 'rgba(255, 225, 150, 0.6)');
      sunGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = sunGrad;
      ctx.beginPath();
      ctx.arc(x + w * 0.35, y + h * 0.3, 110, 0, Math.PI * 2);
      ctx.fill();

      // Far Mountain Range (Soft Mauve/Peach)
      ctx.fillStyle = '#c79c96';
      ctx.beginPath();
      ctx.moveTo(x, y + h * 0.52);
      ctx.lineTo(x + w * 0.2, y + h * 0.38);
      ctx.lineTo(x + w * 0.42, y + h * 0.48);
      ctx.lineTo(x + w * 0.65, y + h * 0.34);
      ctx.lineTo(x + w * 0.88, y + h * 0.46);
      ctx.lineTo(x + w, y + h * 0.42);
      ctx.lineTo(x + w, y + h);
      ctx.lineTo(x, y + h);
      ctx.closePath();
      ctx.fill();

      // Middle Mountain Range (Slate Teal)
      ctx.fillStyle = '#6a7e82';
      ctx.beginPath();
      ctx.moveTo(x, y + h * 0.62);
      ctx.lineTo(x + w * 0.28, y + h * 0.46);
      ctx.lineTo(x + w * 0.55, y + h * 0.58);
      ctx.lineTo(x + w * 0.8, y + h * 0.44);
      ctx.lineTo(x + w, y + h * 0.56);
      ctx.lineTo(x + w, y + h);
      ctx.lineTo(x, y + h);
      ctx.closePath();
      ctx.fill();

      // Misty Pine Forest Valley
      ctx.fillStyle = '#394d48';
      ctx.beginPath();
      ctx.moveTo(x, y + h * 0.72);
      ctx.lineTo(x + w, y + h * 0.7);
      ctx.lineTo(x + w, y + h);
      ctx.lineTo(x, y + h);
      ctx.closePath();
      ctx.fill();

      // Forefront Viewpoint Cliff
      ctx.fillStyle = '#1c2824';
      ctx.beginPath();
      ctx.moveTo(x, y + h * 0.8);
      ctx.lineTo(x + w * 0.6, y + h * 0.78);
      ctx.lineTo(x + w, y + h * 0.85);
      ctx.lineTo(x + w, y + h);
      ctx.lineTo(x, y + h);
      ctx.closePath();
      ctx.fill();

      // Two Lovers at the scenic outlook
      drawLoversSilhouette(ctx, x + w * 0.45, y + h * 0.78, 0.6);
      break;
    }

    case 'fairy-lights':
    default: {
      // Twilight Dusk
      const duskGrad = ctx.createLinearGradient(x, y, x, y + h);
      duskGrad.addColorStop(0, '#1c1b33');
      duskGrad.addColorStop(0.5, '#382e54');
      duskGrad.addColorStop(1, '#5c3d5e');
      ctx.fillStyle = duskGrad;
      ctx.fillRect(x, y, w, h);

      // Hanging Garland Strings
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x, y + h * 0.12);
      ctx.quadraticCurveTo(x + w * 0.5, y + h * 0.28, x + w, y + h * 0.14);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(x, y + h * 0.28);
      ctx.quadraticCurveTo(x + w * 0.5, y + h * 0.44, x + w, y + h * 0.3);
      ctx.stroke();

      // Glowing Fairy Bulbs along strings
      for (let i = 0; i <= 10; i++) {
        const t = i / 10;
        const bx1 = x + w * t;
        const by1 = y + (1 - t) * (1 - t) * (h * 0.12) + 2 * (1 - t) * t * (h * 0.28) + t * t * (h * 0.14);

        // Bulb glow
        const bGlow = ctx.createRadialGradient(bx1, by1, 2, bx1, by1, 16);
        bGlow.addColorStop(0, 'rgba(255, 245, 180, 0.9)');
        bGlow.addColorStop(0.4, 'rgba(255, 180, 80, 0.4)');
        bGlow.addColorStop(1, 'transparent');
        ctx.fillStyle = bGlow;
        ctx.beginPath();
        ctx.arc(bx1, by1, 16, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(bx1, by1, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // Heart Light in hands or center
      const heartX = x + w * 0.5;
      const heartY = y + h * 0.62;
      const hGlow = ctx.createRadialGradient(heartX, heartY, 5, heartX, heartY, 65);
      hGlow.addColorStop(0, 'rgba(255, 120, 150, 0.9)');
      hGlow.addColorStop(0.5, 'rgba(255, 80, 120, 0.3)');
      hGlow.addColorStop(1, 'transparent');
      ctx.fillStyle = hGlow;
      ctx.beginPath();
      ctx.arc(heartX, heartY, 65, 0, Math.PI * 2);
      ctx.fill();

      // Cute Glowing Heart
      ctx.fillStyle = '#ffffff';
      ctx.font = '28px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('♥', heartX, heartY);

      // Wooden bridge / balcony deck
      ctx.fillStyle = '#18121f';
      ctx.fillRect(x, y + h * 0.82, w, h * 0.18);
      ctx.strokeStyle = '#2b1f36';
      ctx.lineWidth = 3;
      ctx.strokeRect(x, y + h * 0.82, w, 6);

      // Balcony railing posts
      for (let i = 0; i < 9; i++) {
        ctx.strokeRect(x + (i * w) / 8, y + h * 0.82, 4, h * 0.18);
      }
      break;
    }
  }
}

/**
 * Draws lovers silhouette standing and holding hands
 */
function drawLoversSilhouette(
  ctx: CanvasRenderingContext2D,
  cx: number,
  groundY: number,
  scale: number
) {
  ctx.save();
  ctx.translate(cx, groundY);
  ctx.scale(scale, scale);
  ctx.fillStyle = '#1a0d1a';

  // Left Figure (e.g. leaning in)
  // Head
  ctx.beginPath();
  ctx.arc(-14, -68, 8, 0, Math.PI * 2);
  ctx.fill();
  // Body / Torso
  ctx.beginPath();
  ctx.moveTo(-16, -60);
  ctx.lineTo(-6, -60);
  ctx.lineTo(-4, -30);
  ctx.lineTo(-12, -30);
  ctx.closePath();
  ctx.fill();
  // Legs
  ctx.lineWidth = 4;
  ctx.strokeStyle = '#1a0d1a';
  ctx.beginPath();
  ctx.moveTo(-12, -30);
  ctx.lineTo(-13, 0);
  ctx.moveTo(-6, -30);
  ctx.lineTo(-5, 0);
  ctx.stroke();

  // Right Figure (e.g. dress or leaning in)
  // Head
  ctx.beginPath();
  ctx.arc(14, -66, 7.5, 0, Math.PI * 2);
  ctx.fill();
  // Torso / Dress
  ctx.beginPath();
  ctx.moveTo(7, -58);
  ctx.lineTo(21, -58);
  ctx.lineTo(24, -18);
  ctx.lineTo(4, -18);
  ctx.closePath();
  ctx.fill();
  // Legs
  ctx.beginPath();
  ctx.moveTo(11, -18);
  ctx.lineTo(10, 0);
  ctx.moveTo(17, -18);
  ctx.lineTo(18, 0);
  ctx.stroke();

  // Connected hands in center
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-6, -45);
  ctx.lineTo(0, -38);
  ctx.lineTo(6, -44);
  ctx.stroke();

  // Little heart above their heads
  ctx.fillStyle = '#ff758c';
  ctx.font = '12px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('♥', 0, -78);

  ctx.restore();
}

/**
 * Draws couple sitting close together
 */
function drawLoversSitting(
  ctx: CanvasRenderingContext2D,
  cx: number,
  groundY: number,
  scale: number
) {
  ctx.save();
  ctx.translate(cx, groundY);
  ctx.scale(scale, scale);
  ctx.fillStyle = '#221b20';

  // Left head resting on shoulder
  ctx.beginPath();
  ctx.arc(-8, -42, 7, 0, Math.PI * 2);
  ctx.fill();

  // Right head
  ctx.beginPath();
  ctx.arc(6, -46, 7.5, 0, Math.PI * 2);
  ctx.fill();

  // Combined cozy silhouette
  ctx.beginPath();
  ctx.roundRect(-20, -36, 40, 36, [14, 14, 4, 4]);
  ctx.fill();

  ctx.fillStyle = '#ff85a1';
  ctx.font = '11px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('♥', -1, -56);

  ctx.restore();
}

/**
 * Draws decorative pine tree silhouette
 */
function drawPineTree(ctx: CanvasRenderingContext2D, x: number, y: number, height: number) {
  ctx.save();
  ctx.fillStyle = '#0a0d15';
  ctx.beginPath();
  ctx.moveTo(x, y - height);
  ctx.lineTo(x + height * 0.35, y);
  ctx.lineTo(x - height * 0.35, y);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

/**
 * Draws vintage wine glass
 */
function drawWineGlass(ctx: CanvasRenderingContext2D, x: number, y: number, angle: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  ctx.strokeStyle = 'rgba(255, 230, 200, 0.65)';
  ctx.lineWidth = 1.5;

  // Bowl
  ctx.beginPath();
  ctx.arc(0, 0, 10, 0, Math.PI);
  ctx.lineTo(8, -8);
  ctx.moveTo(-8, -8);
  ctx.lineTo(-10, 0);
  ctx.stroke();

  // Red Wine inside
  ctx.fillStyle = 'rgba(168, 25, 45, 0.7)';
  ctx.beginPath();
  ctx.arc(0, 2, 7, 0, Math.PI);
  ctx.fill();

  // Stem & Base
  ctx.beginPath();
  ctx.moveTo(0, 10);
  ctx.lineTo(0, 24);
  ctx.moveTo(-8, 24);
  ctx.lineTo(8, 24);
  ctx.stroke();

  ctx.restore();
}

/**
 * Applies color tinting / film styles
 */
function applyFilter(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  filter: PolaroidFilter
) {
  ctx.save();

  switch (filter) {
    case 'vintage':
      // Amber tone overlay
      ctx.fillStyle = 'rgba(255, 215, 140, 0.18)';
      ctx.fillRect(x, y, w, h);
      // Soft vignette
      applyVignette(ctx, x, y, w, h, 0.4);
      break;

    case 'golden':
      // Rich sunset gold
      ctx.fillStyle = 'rgba(255, 175, 75, 0.22)';
      ctx.fillRect(x, y, w, h);
      applyVignette(ctx, x, y, w, h, 0.3);
      break;

    case 'sepia':
      ctx.fillStyle = 'rgba(112, 66, 20, 0.28)';
      ctx.fillRect(x, y, w, h);
      applyVignette(ctx, x, y, w, h, 0.5);
      break;

    case 'pastel':
      ctx.fillStyle = 'rgba(255, 210, 230, 0.18)';
      ctx.fillRect(x, y, w, h);
      break;

    case 'film-noir': {
      // Black and white monochrome look
      const imgData = ctx.getImageData(x, y, w, h);
      const d = imgData.data;
      for (let i = 0; i < d.length; i += 4) {
        const gray = d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114;
        d[i] = gray;
        d[i + 1] = gray;
        d[i + 2] = gray;
      }
      ctx.putImageData(imgData, x, y);
      applyVignette(ctx, x, y, w, h, 0.6);
      break;
    }

    case 'vibrant':
      // Slight contrast boost
      ctx.fillStyle = 'rgba(255, 240, 220, 0.08)';
      ctx.fillRect(x, y, w, h);
      applyVignette(ctx, x, y, w, h, 0.25);
      break;
  }

  ctx.restore();
}

/**
 * Adds vignette around photo borders
 */
function applyVignette(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  intensity: number
) {
  const cx = x + w / 2;
  const cy = y + h / 2;
  const radius = Math.max(w, h) * 0.65;
  const vig = ctx.createRadialGradient(cx, cy, radius * 0.45, cx, cy, radius);
  vig.addColorStop(0, 'rgba(0,0,0,0)');
  vig.addColorStop(1, `rgba(0,0,0,${intensity})`);
  ctx.fillStyle = vig;
  ctx.fillRect(x, y, w, h);
}

/**
 * Adds delicate photographic film grain
 */
function addFilmGrain(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  ctx.save();
  ctx.fillStyle = '#ffffff';
  for (let i = 0; i < 400; i++) {
    const gx = x + Math.random() * w;
    const gy = y + Math.random() * h;
    const alpha = Math.random() * 0.12;
    ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
    ctx.fillRect(gx, gy, 1, 1);
  }
  ctx.restore();
}
