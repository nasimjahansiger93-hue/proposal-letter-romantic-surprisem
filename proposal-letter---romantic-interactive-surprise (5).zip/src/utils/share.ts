import {
  ProposalConfig,
  DEFAULT_PROPOSAL_CONFIG,
  ThemeType,
  OccasionType,
  SealIconType,
} from '../types';

/**
 * Serializes the current ProposalConfig state into a safe Base64 string.
 * Handles UTF-8 characters properly (emojis, unicode, special accents).
 */
export function serializeConfigToBase64(config: ProposalConfig): string {
  try {
    if (typeof window === 'undefined') return '';
    const json = JSON.stringify(config);
    // UTF-8 safe encoding to binary string then base64
    const binaryString = encodeURIComponent(json).replace(/%([0-9A-F]{2})/g, (_, p1) =>
      String.fromCharCode(parseInt(p1, 16))
    );
    return btoa(binaryString);
  } catch (err) {
    console.error('Failed to serialize proposal config to Base64:', err);
    return '';
  }
}

/**
 * Deserializes a Base64 string back into a ProposalConfig object.
 */
export function deserializeConfigFromBase64(base64Str: string): ProposalConfig | null {
  try {
    if (typeof window === 'undefined' || !base64Str) return null;
    const cleanStr = base64Str.trim();
    // Base64 to binary string then decodeURIComponent for UTF-8
    const binaryString = atob(cleanStr);
    const json = decodeURIComponent(
      Array.prototype.map
        .call(binaryString, (c: string) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
    const parsed = JSON.parse(json);
    if (!parsed || typeof parsed !== 'object') return null;

    return {
      ...DEFAULT_PROPOSAL_CONFIG,
      ...parsed,
    };
  } catch (err) {
    console.error('Failed to deserialize proposal config from Base64:', err);
    return null;
  }
}

/**
 * Encodes the current config into a Base64-encoded URL string.
 */
export function encodeProposalToBase64Url(config: ProposalConfig): string {
  if (typeof window === 'undefined') return '';
  const base64 = serializeConfigToBase64(config);
  const baseUrl = `${window.location.origin}${window.location.pathname}`;
  return base64 ? `${baseUrl}?p=${encodeURIComponent(base64)}` : baseUrl;
}

/**
 * Encodes proposal configuration into URL query parameters (legacy fallback).
 */
export function encodeProposalToUrl(config: ProposalConfig): string {
  return encodeProposalToBase64Url(config);
}

/**
 * Decodes proposal configuration from URL parameters.
 * First checks for Base64 encoded payload ('p' or 'setup'), then falls back to legacy query params.
 */
export function decodeProposalFromUrl(): ProposalConfig {
  if (typeof window === 'undefined') return DEFAULT_PROPOSAL_CONFIG;

  const urlObj = new URL(window.location.href);
  const params = urlObj.searchParams;

  // 1. Check for Base64 encoded payload in query or hash
  const base64Payload =
    params.get('p') ||
    params.get('setup') ||
    params.get('proposal') ||
    (window.location.hash.startsWith('#p=')
      ? window.location.hash.slice(3)
      : window.location.hash.startsWith('#setup=')
      ? window.location.hash.slice(7)
      : null);

  if (base64Payload) {
    const deserialized = deserializeConfigFromBase64(decodeURIComponent(base64Payload));
    if (deserialized) {
      return deserialized;
    }
  }

  // 2. Check for legacy query parameters
  if (!params.toString()) return DEFAULT_PROPOSAL_CONFIG;

  return {
    ...DEFAULT_PROPOSAL_CONFIG,
    recipientName: params.get('to') || DEFAULT_PROPOSAL_CONFIG.recipientName,
    senderName: params.get('from') || DEFAULT_PROPOSAL_CONFIG.senderName,
    occasionType: (params.get('occ') as OccasionType) || DEFAULT_PROPOSAL_CONFIG.occasionType,
    theme: (params.get('thm') as ThemeType) || DEFAULT_PROPOSAL_CONFIG.theme,
    sealIcon: (params.get('seal') as SealIconType) || DEFAULT_PROPOSAL_CONFIG.sealIcon,
    initials: params.get('init') || DEFAULT_PROPOSAL_CONFIG.initials,
    headlinePrefix: params.get('hp') || DEFAULT_PROPOSAL_CONFIG.headlinePrefix,
    headlineHighlight: params.get('hh') || DEFAULT_PROPOSAL_CONFIG.headlineHighlight,
    messageBody: params.get('msg') || DEFAULT_PROPOSAL_CONFIG.messageBody,
    yesButtonText: params.get('yb') || DEFAULT_PROPOSAL_CONFIG.yesButtonText,
    maybeButtonText: params.get('mb') || DEFAULT_PROPOSAL_CONFIG.maybeButtonText,
    yesResponseText: params.get('yr') || DEFAULT_PROPOSAL_CONFIG.yesResponseText,
    runawayNoButton: params.get('runaway') === '1',
    photoUrl: params.get('photo') || '',
    photoCaption: params.get('pcap') || DEFAULT_PROPOSAL_CONFIG.photoCaption,
    showCountdown: params.has('cd') ? params.get('cd') === '1' : DEFAULT_PROPOSAL_CONFIG.showCountdown,
    specialDate: params.get('sdate') || DEFAULT_PROPOSAL_CONFIG.specialDate,
    specialDateTitle: params.get('sdtitle') || DEFAULT_PROPOSAL_CONFIG.specialDateTitle,
    countdownStyle: (params.get('cstyle') as any) || DEFAULT_PROPOSAL_CONFIG.countdownStyle,
    countdownSeparator: (params.get('csep') as any) || DEFAULT_PROPOSAL_CONFIG.countdownSeparator,
    countdownFont: (params.get('cfont') as any) || DEFAULT_PROPOSAL_CONFIG.countdownFont,
    countdownCelebrationMessage: params.get('cmsg') || DEFAULT_PROPOSAL_CONFIG.countdownCelebrationMessage,
  };
}
